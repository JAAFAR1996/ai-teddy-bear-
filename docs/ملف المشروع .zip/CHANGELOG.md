# Changelog

## [Unreleased]
### Added
- Initial project structure
- Core AI interaction framework
- Voice streaming capabilities
- Multi-language support
- Safety and moderation systems
- Parent dashboard prototype

### Core Features
- Real-time voice interaction
- Personalized child profiles
- Adaptive AI personality
- Multi-language support
- Robust safety controls

## [0.1.0] - 2023-06-15
### Initial Release
- Proof of concept
- Basic voice interaction
- Preliminary safety mechanisms
- Core AI response generation
- Basic child profile management

## Roadmap
- [ ] Advanced emotional intelligence
- [ ] Enhanced multilingual capabilities
- [ ] Improved safety filtering
- [ ] Offline mode support
- [ ] Expanded parent control features

## Versioning
We use [Semantic Versioning](https://semver.org/)
- MAJOR version for incompatible API changes
- MINOR version for backwards-compatible features
- PATCH version for backwards-compatible bug fixes

## Contributing
See [CONTRIBUTING.md](CONTRIBUTING.md) for details on how to contribute to this project.
