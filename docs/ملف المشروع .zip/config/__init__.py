"""
Config module for AI Teddy Bear
""" 