# 🧸 دليل التشغيل السريع - AI Teddy Bear System

## 🚀 البدء السريع (30 ثانية)

### الخطوة 1: تفعيل البيئة
```bash
# إذا لم تكن في البيئة الافتراضية
.venv\Scripts\activate

# ستظهر (.venv) في بداية السطر
(.venv) PS C:\Users\jaafa\myenv_311\556\New folder\55\21>
```

### الخطوة 2: تشغيل النظام
```bash
python -m src.main_fixed
```

### الخطوة 3: التحقق من النجاح
ستظهر الرسائل التالية:
```
🧸 Starting AI Teddy Bear Fixed Version...
📍 Access the app at: http://localhost:8000
⏳ Starting server...
✅ تم تحميل التكوين من config.json
📊 API Keys النشطة: OpenAI, Anthropic, ElevenLabs, Azure Speech
✅ Teddy Hardware API (Simple) loaded
INFO:     Uvicorn running on http://127.0.0.1:8000
```

---

## 🌐 الوصول للتطبيق

| الخدمة | الرابط | الوصف |
|---------|---------|--------|
| 🏠 **التطبيق الرئيسي** | http://localhost:8000 | الصفحة الرئيسية |
| 🔍 **Health Check** | http://localhost:8000/health | فحص صحة النظام |
| ⚙️ **إعدادات** | http://localhost:8000/config/status | حالة التكوين |
| 📖 **API Documentation** | http://localhost:8000/docs | توثيق API التفاعلي |

---

## 🧪 اختبار النظام

### اختبار سريع:
```bash
python src/simple_test.py
```

### اختبار شامل:
```bash
python src/final_test.py
```

### النتيجة المتوقعة:
```
🎉 🧸 AI TEDDY BEAR SYSTEM IS FULLY OPERATIONAL! 🧸 🎉
✅ Ready for ESP32 hardware integration
✅ All endpoints working correctly
```

---

## 🔗 ESP32 Endpoints المتاحة

### 💓 Heartbeat (نبضة الجهاز)
```bash
POST /teddy/heartbeat
{
  "device_id": "ESP32-001",
  "uptime": 12345,
  "status": "online",
  "battery_level": 85
}
```

### 🎤 Voice Message (الرسائل الصوتية)
```bash
POST /teddy/voice-message
{
  "session_id": "session_123",
  "device_id": "ESP32-001", 
  "audio_data": "SGVsbG8=",
  "timestamp": 1640995200000
}
```

### 📱 List Devices (قائمة الأجهزة)
```bash
GET /teddy/devices
```

### 🔍 Device Status (حالة الجهاز)
```bash
GET /teddy/device/{device_id}/status
```

---

## ⚠️ استكشاف الأخطاء

### مشكلة: "Module not found"
```bash
# تثبيت المتطلبات
pip install -r requirements_2025.txt
```

### مشكلة: "Port already in use"
```bash
# إنهاء العمليات المتصارعة
taskkill /F /IM python.exe
```

### مشكلة: "Config not found"
```bash
# التأكد من وجود ملف التكوين
ls config/config.json
```

---

## 🎮 وضع التطوير المتقدم

### تشغيل بـ Hot Reload:
```bash
uvicorn src.main_fixed:create_application --host 127.0.0.1 --port 8000 --reload
```

### تشغيل في الخلفية:
```bash
# Windows
python -m src.main_fixed &

# أو
Start-Process python -ArgumentList "-m src.main_fixed"
```

---

## 📊 مراقبة الأداء

### عرض السجلات:
النظام يعرض السجلات مباشرة في Terminal مع:
- ✅ حالة API Keys
- 🔗 تحميل Endpoints
- 📡 طلبات HTTP الواردة

### Metrics متاحة على:
- Prometheus: يمكن تفعيلها في التكوين
- Health endpoint: معلومات الحالة

---

## 🔧 التكوين المخصص

### تحرير الإعدادات:
```bash
# فتح ملف التكوين
notepad config/config.json
```

### API Keys:
```json
{
  "API_KEYS": {
    "OPENAI_API_KEY": "your_key_here",
    "ANTHROPIC_API_KEY": "your_key_here"
  }
}
```

---

## 🛑 إيقاف النظام

### إيقاف عادي:
```
Ctrl + C
```

### إيقاف إجباري:
```bash
taskkill /F /IM python.exe
```

---

## ✨ المميزات المتاحة

- 🤖 **AI Integration** - دمج مع OpenAI و Anthropic
- 🎤 **Voice Processing** - معالجة الرسائل الصوتية  
- 📱 **Device Management** - إدارة أجهزة ESP32
- 🔒 **Security** - حماية متقدمة
- 📊 **Monitoring** - مراقبة الأداء
- 🌐 **REST API** - واجهة برمجية شاملة

---

## 🎯 للمطورين

### إضافة endpoint جديد:
1. فتح `src/quick_teddy_endpoints.py`
2. إضافة function مع decorator `@router.post()` أو `@router.get()`
3. إعادة تشغيل الخادم

### تشغيل الاختبارات:
```bash
python -m pytest tests/
```

---

🎉 **النظام جاهز للاستخدام والتطوير!** 