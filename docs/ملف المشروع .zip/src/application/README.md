# Application

This directory contains the application layer of the project, including services and business logic.
