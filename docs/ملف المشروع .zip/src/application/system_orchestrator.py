import asyncio
import logging
from typing import Dict, Any, Optional, List, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
import json
from pathlib import Path
import signal
from collections import defaultdict
import uuid
import psutil
from opentelemetry import trace

# Modern imports without circular dependencies
from src.application.services.service_registry import ServiceRegistry, ServiceBase
from src.infrastructure.session_manager import RedisSessionManager, SessionData
from src.infrastructure.security.audit_logger import AuditLogger, AuditEventType
from src.infrastructure.observability import trace_async, get_tracer
from src.domain.entities.child import Child
from src.infrastructure.config import get_settings


class SystemState(Enum):
    """System operational states"""
    INITIALIZING = "initializing"
    READY = "ready"
    ACTIVE = "active"
    PAUSED = "paused"
    ERROR = "error"
    SHUTTING_DOWN = "shutting_down"
    STOPPED = "stopped"


class SessionState(Enum):
    """Individual session states"""
    STARTING = "starting"
    WAITING_FOR_WAKE_WORD = "waiting_for_wake_word"
    LISTENING = "listening"
    PROCESSING = "processing"
    RESPONDING = "responding"
    IDLE = "idle"
    ENDING = "ending"


@dataclass
class SystemMetrics:
    """System performance metrics"""
    start_time: datetime
    total_sessions: int = 0
    active_sessions: int = 0
    total_interactions: int = 0
    average_response_time: float = 0.0
    error_count: int = 0
    uptime_percentage: float = 100.0
    memory_usage_mb: float = 0.0
    cpu_usage_percentage: float = 0.0


# Session management is now handled by RedisSessionManager
# No more in-memory session storage!


class SystemEventBus:
    """Event bus for system-wide events"""

    def __init__(self):
        self.subscribers: Dict[str, List[Callable]] = defaultdict(list)
        self.logger = logging.getLogger(self.__class__.__name__)

    def subscribe(self, event_type: str, handler: Callable):
        """Subscribe to an event type"""
        self.subscribers[event_type].append(handler)

    def unsubscribe(self, event_type: str, handler: Callable):
        """Unsubscribe from an event type"""
        if handler in self.subscribers[event_type]:
            self.subscribers[event_type].remove(handler)

    async def publish(self, event_type: str, data: Any):
        """Publish an event"""
        if event_type in self.subscribers:
            for handler in self.subscribers[event_type]:
                try:
                    if asyncio.iscoroutinefunction(handler):
                        await handler(data)
                    else:
                        handler(data)
                except Exception as e:
                    self.logger.error(
                        f"Event handler error for {event_type}: {e}")


class SystemOrchestrator(ServiceBase):
    """
    Modern System Orchestrator using service registry and Redis for state
    """
    
    def __init__(self, registry: ServiceRegistry, config: Dict[str, Any]):
        super().__init__(registry, config)
        self.settings = get_settings()
        self.state = SystemState.INITIALIZING
        self.metrics = SystemMetrics(start_time=datetime.now())
        
        # Services will be injected via registry
        self.session_manager: Optional[RedisSessionManager] = None
        self.audit_logger: Optional[AuditLogger] = None
        
        # Event bus
        self.event_bus = SystemEventBus()
        
        # Background tasks
        self.background_tasks: List[asyncio.Task] = []
        
        # Monitoring intervals
        self.health_check_interval = 60  # seconds
        self.metrics_update_interval = 30  # seconds
        
        # Graceful shutdown
        self.shutdown_event = asyncio.Event()
        
        # Tracer
        self._tracer = get_tracer(__name__)
    
    async def initialize(self) -> None:
        """Initialize the orchestrator"""
        with self._tracer.start_as_current_span("orchestrator_init"):
            self.logger.info("Initializing system orchestrator")
            
            # Get services from registry
            self.session_manager = await self.wait_for_service("session_manager")
            self.audit_logger = await self.wait_for_service("audit_logger")
            
            # Setup event handlers
            self._setup_event_handlers()
            
            # Start background tasks
            await self._start_background_tasks()
            
            self.state = SystemState.READY
            
            # Log initialization
            await self.audit_logger.log_event(
                event_type=AuditEventType.SYSTEM_START,
                action="orchestrator_initialized",
                result="success"
            )
    
    async def shutdown(self) -> None:
        """Shutdown the orchestrator"""
        self.state = SystemState.SHUTTING_DOWN
        self.shutdown_event.set()
        
        # Cancel background tasks
        for task in self.background_tasks:
            task.cancel()
        
        await asyncio.gather(*self.background_tasks, return_exceptions=True)
        
        self.state = SystemState.STOPPED
    
    async def health_check(self) -> Dict[str, Any]:
        """Health check for the orchestrator"""
        return {
            "healthy": self.state == SystemState.READY,
            "state": self.state.value,
            "uptime": (datetime.now() - self.metrics.start_time).total_seconds(),
            "active_sessions": await self._get_active_session_count()
        }
    
    @trace_async("get_detailed_status")
    async def get_detailed_status(self) -> Dict[str, Any]:
        """Get real system status from all services"""
        status = {
            "timestamp": datetime.utcnow().isoformat(),
            "state": self.state.value,
            "services": {}
        }
        
        # Get status from each registered service
        service_names = ["database", "redis", "ai", "moderation", "transcription"]
        
        for service_name in service_names:
            try:
                service = self.registry.get_service(service_name)
                if service:
                    health = await service.health_check()
                    status["services"][service_name] = health.get("healthy", False)
                else:
                    status["services"][service_name] = False
            except Exception as e:
                self.logger.error(f"Failed to check {service_name} health", error=str(e))
                status["services"][service_name] = False
        
        # Get system metrics
        status["metrics"] = await self.get_system_metrics()
        
        return status
    
    async def get_system_metrics(self) -> Dict[str, Any]:
        """Get real system metrics"""
        process = psutil.Process()
        
        return {
            "cpu": {
                "percent": psutil.cpu_percent(interval=1),
                "count": psutil.cpu_count()
            },
            "memory": {
                "percent": psutil.virtual_memory().percent,
                "used_mb": process.memory_info().rss / 1024 / 1024,
                "available_mb": psutil.virtual_memory().available / 1024 / 1024
            },
            "disk": {
                "percent": psutil.disk_usage('/').percent,
                "free_gb": psutil.disk_usage('/').free / 1024 / 1024 / 1024
            },
            "network": {
                "connections": len(process.connections()),
                "bytes_sent": psutil.net_io_counters().bytes_sent,
                "bytes_recv": psutil.net_io_counters().bytes_recv
            },
            "sessions": {
                "active": await self._get_active_session_count(),
                "total": self.metrics.total_sessions
            },
            "uptime_seconds": (datetime.now() - self.metrics.start_time).total_seconds()
        }




    def _setup_event_handlers(self):
        """Setup event handlers for system events"""
        # Session events
        self.event_bus.subscribe(
            "session:started", self._handle_session_started)
        self.event_bus.subscribe("session:ended", self._handle_session_ended)

        # Interaction events
        self.event_bus.subscribe(
            "interaction:complete", self._handle_interaction_complete)

        # Alert events
        self.event_bus.subscribe(
            "alert:moderation", self._handle_moderation_alert)
        self.event_bus.subscribe(
            "alert:time_limit", self._handle_time_limit_alert)

        # System events
        self.event_bus.subscribe("system:error", self._handle_system_error)

    async def _start_background_tasks(self):
        """Start background monitoring tasks"""
        # Health check task
        self.background_tasks.append(
            asyncio.create_task(self._health_check_loop())
        )

        # Metrics update task
        self.background_tasks.append(
            asyncio.create_task(self._metrics_update_loop())
        )

        # Session cleanup task
        self.background_tasks.append(
            asyncio.create_task(self._session_cleanup_loop())
        )

        # Memory consolidation monitor
        self.background_tasks.append(
            asyncio.create_task(self._memory_monitor_loop())
        )

    def _register_signal_handlers(self):
        """Register signal handlers for graceful shutdown"""
        for sig in (signal.SIGTERM, signal.SIGINT):
            signal.signal(
                sig, lambda s, f: asyncio.create_task(self.shutdown()))

    @trace_async("start_session")
    async def start_session(self, child_id: str) -> SessionData:
        """Start a new interaction session using Redis"""
        span = trace.get_current_span()
        span.set_attribute("child_id", child_id)
        
        try:
            # Get services from registry
            child_repository = self.get_service("child_repository")
            parent_dashboard = self.get_service("parent_dashboard")
            ai_service = self.get_service("ai")
            voice_service = self.get_service("voice")
            streaming_service = self.get_service("streaming")
            
            # Get child profile
            child = await child_repository.get(child_id)
            if not child:
                raise ValueError(f"Child not found: {child_id}")

            # Check parental controls
            access_allowed, reason = await parent_dashboard.check_access_allowed(child_id)
            if not access_allowed:
                await self.audit_logger.log_event(
                    event_type=AuditEventType.ACCESS_DENIED,
                    action="session_start",
                    result="denied",
                    child_id=child_id,
                    details={"reason": reason}
                )
                raise PermissionError(f"Access denied: {reason}")

            # Create session in Redis
            session = await self.session_manager.create_session(
                user_id=child_id,
                child_id=child_id,
                data={
                    "state": SessionState.STARTING.value,
                    "child_name": child.name,
                    "language": child.preferences.language,
                    "age": child.age
                },
                metadata={
                    "start_time": datetime.now().isoformat(),
                    "device_type": "teddy_bear"
                }
            )

            # Update metrics
            self.metrics.total_sessions += 1
            self.metrics.active_sessions += 1

            # Initialize AI context
            await ai_service.create_session_context(child, session.session_id)

            # Start voice interaction
            profile_id = 'teddy_bear_ar' if child.preferences.language == 'ar' else 'teddy_bear'
            await voice_service.start_voice_interaction(
                profile_id=profile_id,
                session_id=session.session_id
            )

            # Start streaming
            await streaming_service.start()

            # Update session state in Redis
            await self.session_manager.update_session(
                session.session_id,
                data={"state": SessionState.WAITING_FOR_WAKE_WORD.value}
            )

            self.state = SystemState.ACTIVE

            # Publish event
            await self.event_bus.publish("session:started", {
                "session_id": session.session_id,
                "child_id": child_id,
                "timestamp": datetime.now().isoformat()
            })

            # Log audit event
            await self.audit_logger.log_event(
                event_type=AuditEventType.SESSION_START,
                action="session_started",
                result="success",
                child_id=child_id,
                session_id=session.session_id
            )

            self.logger.info(
                f"Session started: {session.session_id} for child {child_id}")

            return session

        except Exception as e:
            span.record_exception(e)
            self.logger.error(f"Failed to start session: {e}")
            self.metrics.error_count += 1
            
            # Log audit event
            await self.audit_logger.log_event(
                event_type=AuditEventType.ERROR_OCCURRED,
                action="session_start",
                result="failure",
                child_id=child_id,
                details={"error": str(e)}
            )
            raise

    @trace_async("end_session")
    async def end_session(self, session_id: str):
        """End an interaction session using Redis"""
        try:
            # Get session from Redis
            session = await self.session_manager.get_session(session_id)
            if not session:
                self.logger.warning(f"Session not found: {session_id}")
                return

            # Update session state
            await self.session_manager.update_session(
                session_id,
                data={"state": SessionState.ENDING.value}
            )

            # Calculate session duration
            start_time = datetime.fromisoformat(session.metadata.get("start_time", datetime.now().isoformat()))
            total_duration = datetime.now() - start_time

            # Get services
            voice_service = self.get_service("voice")
            memory_service = self.get_service("memory")
            streaming_service = self.get_service("streaming")

            # Stop voice interaction
            await voice_service.stop_voice_interaction()

            # Create conversation summary
            await memory_service.create_conversation_summary(
                session_id=session_id,
                child_id=session.child_id,
                start_time=start_time,
                end_time=datetime.now()
            )

            # End streaming session
            await streaming_service.end_conversation_session(session_id)

            # Update metrics
            self.metrics.active_sessions = max(0, self.metrics.active_sessions - 1)

            # Delete session from Redis
            await self.session_manager.delete_session(session_id)

            # Publish event
            await self.event_bus.publish("session:ended", {
                "session_id": session_id,
                "child_id": session.child_id,
                "duration_seconds": total_duration.total_seconds(),
                "interaction_count": session.data.get("interaction_count", 0),
                "timestamp": datetime.now().isoformat()
            })

            # Log audit event
            await self.audit_logger.log_event(
                event_type=AuditEventType.LOGOUT,
                action="session_ended",
                result="success",
                child_id=session.child_id,
                session_id=session_id,
                details={
                    "duration_seconds": total_duration.total_seconds(),
                    "interaction_count": session.data.get("interaction_count", 0)
                }
            )

            self.logger.info(f"Session ended: {session_id}")

        except Exception as e:
            self.logger.error(f"Failed to end session: {e}")
            self.metrics.error_count += 1
            
            await self.audit_logger.log_event(
                event_type=AuditEventType.ERROR_OCCURRED,
                action="session_end",
                result="failure",
                session_id=session_id,
                details={"error": str(e)}
            )

    async def _get_active_session_count(self) -> int:
        """Get count of active sessions from Redis"""
        sessions = await self.session_manager.get_active_sessions()
        return len(sessions)


    # Background task loops

    async def _health_check_loop(self):
        """Periodic health check"""
        while not self.shutdown_event.is_set():
            try:
                await asyncio.sleep(self.health_check_interval)

                # Check service health
                health_status = await self._check_services_health()

                if not health_status['healthy']:
                    self.logger.warning(
                        f"Health check failed: {health_status['issues']}")
                    await self.event_bus.publish("system:health_check_failed", health_status)

            except Exception as e:
                self.logger.error(f"Health check error: {e}")

    async def _metrics_update_loop(self):
        """Update system metrics"""
        while not self.shutdown_event.is_set():
            try:
                await asyncio.sleep(self.metrics_update_interval)

                # Update memory usage
                import psutil
                process = psutil.Process()
                self.metrics.memory_usage_mb = process.memory_info().rss / 1024 / 1024
                self.metrics.cpu_usage_percentage = process.cpu_percent(
                    interval=1)

                # Calculate uptime percentage
                total_time = (datetime.now() -
                              self.metrics.start_time).total_seconds()
                error_penalty = self.metrics.error_count * 60  # 1 minute penalty per error
                self.metrics.uptime_percentage = max(0, min(100,
                                                            (1 - error_penalty /
                                                             total_time) * 100
                                                            ))

            except Exception as e:
                self.logger.error(f"Metrics update error: {e}")

    async def _session_cleanup_loop(self):
        """Clean up inactive sessions from Redis"""
        while not self.shutdown_event.is_set():
            try:
                await asyncio.sleep(60)  # Check every minute
                
                # Use Redis session manager to clean up
                cleaned = await self.session_manager.cleanup_expired_sessions()
                if cleaned > 0:
                    self.logger.info(f"Cleaned up {cleaned} expired sessions")

            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Session cleanup error: {e}")

    async def _memory_monitor_loop(self):
        """Monitor memory service"""
        while not self.shutdown_event.is_set():
            try:
                await asyncio.sleep(300)  # Every 5 minutes

            except Exception as e:
                self.logger.error(f"Memory monitor error: {e}")

    # Event handlers

    async def _handle_session_started(self, data: Dict[str, Any]):
        """Handle session started event"""
        self.logger.info(f"Session started event: {data}")

    async def _handle_session_ended(self, data: Dict[str, Any]):
        """Handle session ended event"""
        self.logger.info(f"Session ended event: {data}")

        # Get parent dashboard service and log
        try:
            parent_dashboard = self.get_service("parent_dashboard")
            if parent_dashboard:
                await parent_dashboard.end_conversation_session(data['session_id'])
        except Exception as e:
            self.logger.error(f"Failed to notify parent dashboard: {e}")

    async def _handle_interaction_complete(self, data: Dict[str, Any]):
        """Handle interaction complete event"""
        pass

    async def _handle_moderation_alert(self, data: Dict[str, Any]):
        """Handle moderation alert"""
        self.logger.warning(f"Moderation alert: {data}")

        # Get parent dashboard service
        try:
            parent_dashboard = self.get_service("parent_dashboard")
            if parent_dashboard:
                await parent_dashboard.send_moderation_alert(
                    user_id=data['child_id'],
                    alert_type=data['alert_type'],
                    severity=data['severity'],
                    details=data['details']
                )
        except Exception as e:
            self.logger.error(f"Failed to send moderation alert: {e}")

    async def _handle_time_limit_alert(self, data: Dict[str, Any]):
        """Handle time limit alert"""
        self.logger.info(f"Time limit alert: {data}")

        # End session if limit exceeded
        if data['action'] == 'end_session':
            await self.end_session(data['session_id'])

    async def _handle_system_error(self, data: Dict[str, Any]):
        """Handle system error event"""
        self.logger.error(f"System error: {data}")
        self.metrics.error_count += 1

        # Determine if error is critical
        if data.get('severity') == 'critical':
            self.state = SystemState.ERROR

    # Helper methods

    async def _check_services_health(self) -> Dict[str, Any]:
        """Check health of all services using registry"""
        issues = []
        
        # Check critical services
        critical_services = ["database", "redis", "ai", "moderation", "transcription"]
        
        for service_name in critical_services:
            try:
                service = self.registry.get_service(service_name)
                if service:
                    health = await service.health_check()
                    if not health.get("healthy", True):
                        issues.append(f"{service_name} service unhealthy")
                else:
                    issues.append(f"{service_name} service not available")
            except Exception as e:
                issues.append(f"{service_name} health check failed: {str(e)}")

        return {
            "healthy": len(issues) == 0,
            "issues": issues,
            "timestamp": datetime.now().isoformat()
        }

    def _update_average_response_time(self, response_time: float):
        """Update average response time metric"""
        # Simple moving average
        alpha = 0.1  # Smoothing factor
        self.metrics.average_response_time = (
            alpha * response_time +
            (1 - alpha) * self.metrics.average_response_time
        )

    async def _save_metrics(self):
        """Save system metrics to file"""
        try:
            metrics_path = Path(self.config.get(
                'METRICS_PATH', 'data/metrics'))
            metrics_path.mkdir(parents=True, exist_ok=True)

            metrics_file = metrics_path / \
                f"metrics_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"

            metrics_data = {
                "start_time": self.metrics.start_time.isoformat(),
                "end_time": datetime.now().isoformat(),
                "total_sessions": self.metrics.total_sessions,
                "total_interactions": self.metrics.total_interactions,
                "average_response_time": self.metrics.average_response_time,
                "error_count": self.metrics.error_count,
                "uptime_percentage": self.metrics.uptime_percentage
            }

            with open(metrics_file, 'w') as f:
                json.dump(metrics_data, f, indent=2)

            self.logger.info(f"Metrics saved to {metrics_file}")

        except Exception as e:
            self.logger.error(f"Failed to save metrics: {e}")


# The SystemOrchestrator is now a service that gets registered in the ServiceRegistry
# See main.py for the actual application entry point
