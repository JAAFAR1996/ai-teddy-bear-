# Domain

This directory contains the domain layer of the project, including entities and repositories.
