"""Enhanced high-level audio system manager for AI Teddy Bear."""

import logging
import asyncio
import threading
import time
from typing import Optional, List, Tuple, Callable, Dict, Any, Union
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from datetime import datetime, timedelta
import numpy as np
import json

from .audio_recorder import AudioRecorder
from .audio_processing import AudioProcessor, process_audio
from .audio_io import AudioIO, AudioFormat, AudioQuality, AudioMetadata
from .tts_playback import TTSPlayback
from .state_manager import state_manager, StateChangeEvent, AudioState


class AudioSessionType(Enum):
    """Types of audio sessions."""
    CONVERSATION = "conversation"
    STORY_TELLING = "story_telling"
    LEARNING = "learning"
    PLAY_TIME = "play_time"
    EMERGENCY = "emergency"
    SYSTEM_TEST = "system_test"


class AudioQualityMode(Enum):
    """Audio quality modes for different scenarios."""
    POWER_SAVE = "power_save"      # Low quality, minimal processing
    BALANCED = "balanced"          # Good quality, moderate processing
    HIGH_QUALITY = "high_quality"  # Best quality, full processing
    ADAPTIVE = "adaptive"          # Auto-adjust based on conditions


@dataclass
class AudioSession:
    """Audio session information."""
    session_id: str
    session_type: AudioSessionType
    child_id: str
    start_time: datetime
    end_time: Optional[datetime] = None
    total_recordings: int = 0
    total_duration: float = 0.0
    quality_mode: AudioQualityMode = AudioQualityMode.BALANCED
    metadata: Dict[str, Any] = None

    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


@dataclass
class AudioSystemConfig:
    """Audio system configuration."""
    default_record_duration: int = 10
    max_record_duration: int = 60
    auto_process_audio: bool = True
    auto_save_sessions: bool = True
    noise_reduction_enabled: bool = True
    voice_activity_detection: bool = True
    adaptive_quality: bool = True
    emergency_override: bool = True
    session_timeout_minutes: int = 30
    max_concurrent_sessions: int = 3
    volume_level: float = 0.8
    language_preference: str = "en"
    child_safe_mode: bool = True


class AudioSystemError(Exception):
    """Audio system error."""
    pass


class AudioManager:
    """Enhanced audio system manager with advanced features."""

    def __init__(self, config: Optional[AudioSystemConfig] = None):
        """
        Initialize enhanced audio manager.

        Args:
            config: Audio system configuration
        """
        self.logger = logging.getLogger(__name__)
        self.config = config or AudioSystemConfig()

        # Component initialization
        self._initialize_components()

        # Session management
        self.active_sessions: Dict[str, AudioSession] = {}
        self.current_session: Optional[AudioSession] = None
        self._session_lock = threading.Lock()

        # Performance monitoring
        self.performance_stats = {
            "total_recordings": 0,
            "total_playbacks": 0,
            "total_errors": 0,
            "average_processing_time": 0.0,
            "last_error": None,
            "uptime_start": datetime.now()
        }

        # Event callbacks
        self.event_callbacks: Dict[str, List[Callable]] = {
            "session_start": [],
            "session_end": [],
            "recording_start": [],
            "recording_end": [],
            "playback_start": [],
            "playback_end": [],
            "error": [],
            "quality_change": []
        }

        # Background tasks
        self._monitoring_task = None
        self._cleanup_task = None
        self._start_background_tasks()

        # Register state observers
        state_manager.add_observer("error", self._handle_error)
        state_manager.add_observer(
            "recording_change", self._handle_recording_state)
        state_manager.add_observer(
            "playback_change", self._handle_playback_state)

        self.logger.info("Enhanced audio manager initialized")

    def _initialize_components(self):
        """Initialize audio system components."""
        try:
            self.recorder = AudioRecorder()
            self.processor = AudioProcessor()
            self.audio_io = AudioIO(auto_cleanup=True)
            self.tts = TTSPlayback(on_playback_complete=self._on_playback_complete)

            # Configure components based on settings
            self._configure_components()

        except Exception as e:
            self.logger.error(f"Error initializing audio components: {e}")
            raise AudioSystemError(f"Failed to initialize audio system: {e}")

    def _configure_components(self):
        """Configure components based on current settings."""
        try:
            # Configure recorder
            if hasattr(self.recorder, 'set_noise_reduction'):
                self.recorder.set_noise_reduction(
                    self.config.noise_reduction_enabled)

            # Configure TTS volume
            if hasattr(self.tts, 'set_volume'):
                self.tts.set_volume(self.config.volume_level)

            # Configure processor for child-safe mode
            if hasattr(self.processor, 'set_child_safe_mode'):
                self.processor.set_child_safe_mode(self.config.child_safe_mode)

        except Exception as e:
            self.logger.warning(f"Error configuring components: {e}")

    def _start_background_tasks(self):
        """Start background monitoring and cleanup tasks."""
        try:
            # Start monitoring task
            self._monitoring_task = threading.Thread(
                target=self._monitoring_worker,
                daemon=True
            )
            self._monitoring_task.start()

            # Start cleanup task
            self._cleanup_task = threading.Thread(
                target=self._cleanup_worker,
                daemon=True
            )
            self._cleanup_task.start()

        except Exception as e:
            self.logger.error(f"Error starting background tasks: {e}")

    def _monitoring_worker(self):
        """Background worker for system monitoring."""
        while True:
            try:
                # Check session timeouts
                self._check_session_timeouts()

                # Update performance stats
                self._update_performance_stats()

                # Check system health
                self._check_system_health()

                # Sleep for 30 seconds
                threading.Event().wait(30)

            except Exception as e:
                self.logger.error(f"Error in monitoring worker: {e}")
                threading.Event().wait(60)  # Wait longer on error

    def _cleanup_worker(self):
        """Background worker for cleanup tasks."""
        while True:
            try:
                # Cleanup temporary files
                self.audio_io.cleanup_temp_files()

                # Cleanup old TTS cache
                if hasattr(self.tts, 'cleanup_cache'):
                    self.tts.cleanup_cache()

                # Cleanup old session data
                self._cleanup_old_sessions()

                # Sleep for 1 hour
                threading.Event().wait(3600)

            except Exception as e:
                self.logger.error(f"Error in cleanup worker: {e}")
                threading.Event().wait(1800)  # Wait 30 min on error

    def start_session(
        self,
        child_id: str,
        session_type: AudioSessionType = AudioSessionType.CONVERSATION,
        quality_mode: AudioQualityMode = AudioQualityMode.BALANCED
    ) -> str:
        """
        Start a new audio session.

        Args:
            child_id: Child identifier
            session_type: Type of audio session
            quality_mode: Audio quality mode

        Returns:
            Session ID
        """
        try:
            with self._session_lock:
                # Check concurrent session limit
                if len(self.active_sessions) >= self.config.max_concurrent_sessions:
                    # End oldest session
                    oldest_session_id = min(
                        self.active_sessions.keys(),
                        key=lambda sid: self.active_sessions[sid].start_time
                    )
                    self.end_session(oldest_session_id)

                # Create new session
                session_id = f"session_{child_id}_{int(time.time())}"
                session = AudioSession(
                    session_id=session_id,
                    session_type=session_type,
                    child_id=child_id,
                    start_time=datetime.now(),
                    quality_mode=quality_mode
                )

                self.active_sessions[session_id] = session
                self.current_session = session

                # Configure quality mode
                self._set_quality_mode(quality_mode)

                # Trigger callbacks
                self._trigger_event("session_start", {
                    "session_id": session_id,
                    "child_id": child_id,
                    "session_type": session_type.value
                })

                self.logger.info(
                    f"Started audio session {session_id} for child {child_id}")
                return session_id

        except Exception as e:
            self.logger.error(f"Error starting session: {e}")
            raise AudioSystemError(f"Failed to start session: {e}")

    def end_session(self, session_id: str) -> bool:
        """
        End an audio session.

        Args:
            session_id: Session to end

        Returns:
            Success status
        """
        try:
            with self._session_lock:
                if session_id not in self.active_sessions:
                    self.logger.warning(f"Session {session_id} not found")
                    return False

                session = self.active_sessions[session_id]
                session.end_time = datetime.now()

                # Save session data if configured
                if self.config.auto_save_sessions:
                    self._save_session_data(session)

                # Remove from active sessions
                del self.active_sessions[session_id]

                # Update current session
                if self.current_session and self.current_session.session_id == session_id:
                    self.current_session = None

                # Trigger callbacks
                self._trigger_event("session_end", {
                    "session_id": session_id,
                    "duration": (session.end_time - session.start_time).total_seconds(),
                    "recordings": session.total_recordings
                })

                self.logger.info(f"Ended audio session {session_id}")
                return True

        except Exception as e:
            self.logger.error(f"Error ending session: {e}")
            return False

    def record_audio(
        self,
        duration: Optional[int] = None,
        process: bool = None,
        save: bool = None,
        filename: Optional[str] = None,
        session_id: Optional[str] = None
    ) -> Optional[Tuple[np.ndarray, AudioMetadata]]:
        """
        Record audio with enhanced options.

        Args:
            duration: Recording duration (uses config default if None)
            process: Whether to process audio (uses config default if None)
            save: Whether to save audio (uses config default if None)
            filename: Custom filename for saving
            session_id: Session to associate recording with

        Returns:
            Tuple of (audio_data, metadata) or None
        """
        try:
            # Use configuration defaults
            if duration is None:
                duration = self.config.default_record_duration
            if process is None:
                process = self.config.auto_process_audio
            if save is None:
                save = self.config.auto_save_sessions

            # Validate duration
            duration = min(duration, self.config.max_record_duration)

            # Check if already recording
            if self.recorder.is_recording():
                self.logger.warning("Recording already in progress")
                return None

            # Get or create session
            if session_id and session_id in self.active_sessions:
                session = self.active_sessions[session_id]
            else:
                session = self.current_session

            # Trigger recording start event
            self._trigger_event("recording_start", {
                "duration": duration,
                "session_id": session.session_id if session else None
            })

            start_time = time.time()

            # Record audio
            self.logger.info(f"Starting recording for {duration} seconds")
            audio_data = self.recorder.record_audio(duration)

            if audio_data is None or len(audio_data) == 0:
                self.logger.error("No audio data recorded")
                return None

            # Create metadata
            metadata = AudioMetadata(
                filename=filename or "recording",
                format="wav",
                duration=len(audio_data) / 16000,  # Assuming 16kHz
                sample_rate=16000,
                channels=1,
                created_at=datetime.now(),
                tags={
                    "session_id": session.session_id if session else None,
                    "child_id": session.child_id if session else None,
                    "recording_type": "user_input"
                }
            )

            # Process audio if requested
            if process:
                state_manager.set_processing(True)
                try:
                    processed_audio = process_audio(audio_data)
                    if processed_audio is not None:
                        audio_data = processed_audio
                        metadata.tags["processed"] = True
                finally:
                    state_manager.set_processing(False)

            # Save if requested
            if save:
                if filename is None:
                    filename = self.audio_io.create_temp_file(
                        prefix=f"rec_{session.child_id if session else 'unknown'}_"
                    )

                self.audio_io.save_audio(
                    audio_data,
                    filename,
                    metadata=metadata.tags
                )
                metadata.filename = filename

            # Update session stats
            if session:
                session.total_recordings += 1
                session.total_duration += metadata.duration

            # Update performance stats
            processing_time = time.time() - start_time
            self.performance_stats["total_recordings"] += 1
            self._update_avg_processing_time(processing_time)

            # Trigger recording end event
            self._trigger_event("recording_end", {
                "duration": metadata.duration,
                "processing_time": processing_time,
                "session_id": session.session_id if session else None
            })

            self.logger.info(f"Recording completed: {metadata.duration:.2f}s")
            return audio_data, metadata

        except Exception as e:
            self.logger.error(f"Error recording audio: {e}")
            self.performance_stats["total_errors"] += 1
            self.performance_stats["last_error"] = str(e)
            state_manager.set_error(str(e))
            return None

    def play_audio(
        self,
        audio_data: Optional[np.ndarray] = None,
        filename: Optional[str] = None,
        volume: Optional[float] = None,
        session_id: Optional[str] = None
    ) -> bool:
        """
        Play audio with enhanced options.

        Args:
            audio_data: Audio data to play
            filename: Audio file to play
            volume: Playback volume (0.0-1.0)
            session_id: Session to associate playback with

        Returns:
            Success status
        """
        try:
            # Check inputs
            if audio_data is None and filename is None:
                raise ValueError("Must provide audio_data or filename")

            # Get session info
            session = None
            if session_id and session_id in self.active_sessions:
                session = self.active_sessions[session_id]
            elif self.current_session:
                session = self.current_session

            # Load from file if needed
            if audio_data is None:
                audio_data, sample_rate, metadata = self.audio_io.load_audio(
                    filename)
                duration = metadata.duration
            else:
                duration = len(audio_data) / 16000  # Assuming 16kHz

            # Set volume if specified
            if volume is not None:
                volume = max(0.0, min(1.0, volume))  # Clamp to valid range
                if hasattr(self.tts, 'set_volume'):
                    self.tts.set_volume(volume)

            # Trigger playback start event
            self._trigger_event("playback_start", {
                "duration": duration,
                "session_id": session.session_id if session else None,
                "volume": volume or self.config.volume_level
            })

            start_time = time.time()

            # Play audio
            if hasattr(self.tts, '_play_audio'):
                self.tts._play_audio(audio_data)
            else:
                # Fallback method
                self.tts.play_audio(audio_data)

            # Update performance stats
            playback_time = time.time() - start_time
            self.performance_stats["total_playbacks"] += 1

            # Trigger playback end event
            self._trigger_event("playback_end", {
                "duration": duration,
                "actual_time": playback_time,
                "session_id": session.session_id if session else None
            })

            return True

        except Exception as e:
            self.logger.error(f"Error playing audio: {e}")
            self.performance_stats["total_errors"] += 1
            self.performance_stats["last_error"] = str(e)
            state_manager.set_error(str(e))
            return False

    def speak(
        self,
        text: str,
        language: Optional[str] = None,
        speed: float = 1.0,
        volume: Optional[float] = None,
        cache: bool = True,
        session_id: Optional[str] = None
    ) -> bool:
        """
        Enhanced text-to-speech with session support.

        Args:
            text: Text to speak
            language: Language code (uses config default if None)
            speed: Speech speed multiplier
            volume: Speech volume (0.0-1.0)
            cache: Whether to cache generated speech
            session_id: Session to associate speech with

        Returns:
            Success status
        """
        try:
            # Use configuration defaults
            if language is None:
                language = self.config.language_preference

            # Get session info
            session = None
            if session_id and session_id in self.active_sessions:
                session = self.active_sessions[session_id]
            elif self.current_session:
                session = self.current_session

            # Set volume if specified
            if volume is not None:
                volume = max(0.0, min(1.0, volume))
                if hasattr(self.tts, 'set_volume'):
                    self.tts.set_volume(volume)

            # Add session context to TTS metadata
            tts_metadata = {
                "session_id": session.session_id if session else None,
                "child_id": session.child_id if session else None,
                "timestamp": datetime.now().isoformat()
            }

            # Generate and play speech
            if hasattr(self.tts, 'speak_with_metadata'):
                success = self.tts.speak_with_metadata(
                    text, language, speed, cache, tts_metadata
                )
            else:
                success = self.tts.speak(text, language, speed, cache)

            if success:
                self.logger.info(
                    f"TTS completed for session {session.session_id if session else 'none'}")

            return success

        except Exception as e:
            self.logger.error(f"Error in text-to-speech: {e}")
            self.performance_stats["total_errors"] += 1
            self.performance_stats["last_error"] = str(e)
            state_manager.set_error(str(e))
            return False

    def stop_all(self, session_id: Optional[str] = None):
        """
        Stop all audio operations, optionally for specific session.

        Args:
            session_id: Specific session to stop (None for all)
        """
        try:
            if session_id:
                self.logger.info(
                    f"Stopping audio operations for session {session_id}")
            else:
                self.logger.info("Stopping all audio operations")

            # Stop recording
            if self.recorder.is_recording():
                self.recorder.stop_recording()

            # Stop playback
            if hasattr(self.tts, 'is_playing') and self.tts.is_playing():
                self.tts.stop()

            # Stop any ongoing processing
            state_manager.set_processing(False)

            self.logger.info("Audio operations stopped successfully")

        except Exception as e:
            self.logger.error(f"Error stopping operations: {e}")
            state_manager.set_error(str(e))

    def get_session_info(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        Get information about an audio session.

        Args:
            session_id: Session ID

        Returns:
            Session information dictionary
        """
        if session_id not in self.active_sessions:
            return None

        session = self.active_sessions[session_id]
        current_duration = (
            datetime.now() - session.start_time).total_seconds()

        return {
            "session_id": session.session_id,
            "session_type": session.session_type.value,
            "child_id": session.child_id,
            "start_time": session.start_time.isoformat(),
            "current_duration": current_duration,
            "total_recordings": session.total_recordings,
            "total_audio_duration": session.total_duration,
            "quality_mode": session.quality_mode.value,
            "metadata": session.metadata
        }

    def get_system_stats(self) -> Dict[str, Any]:
        """Get comprehensive system statistics."""
        uptime = (datetime.now() -
                  self.performance_stats["uptime_start"]).total_seconds()

        return {
            "performance": self.performance_stats.copy(),
            "uptime_seconds": uptime,
            "active_sessions": len(self.active_sessions),
            "current_session": self.current_session.session_id if self.current_session else None,
            "configuration": {
                "auto_process": self.config.auto_process_audio,
                "auto_save": self.config.auto_save_sessions,
                "noise_reduction": self.config.noise_reduction_enabled,
                "child_safe_mode": self.config.child_safe_mode,
                "volume_level": self.config.volume_level,
                "language": self.config.language_preference
            },
            "component_status": {
                "recorder_available": hasattr(self, 'recorder') and self.recorder is not None,
                "processor_available": hasattr(self, 'processor') and self.processor is not None,
                "tts_available": hasattr(self, 'tts') and self.tts is not None,
                "audio_io_available": hasattr(self, 'audio_io') and self.audio_io is not None
            }
        }

    def _set_quality_mode(self, quality_mode: AudioQualityMode):
        """Set audio quality mode for all components."""
        try:
            quality_config = {
                AudioQualityMode.POWER_SAVE: {
                    "sample_rate": 8000,
                    "processing_level": "minimal",
                    "noise_reduction": False
                },
                AudioQualityMode.BALANCED: {
                    "sample_rate": 16000,
                    "processing_level": "standard",
                    "noise_reduction": True
                },
                AudioQualityMode.HIGH_QUALITY: {
                    "sample_rate": 22050,
                    "processing_level": "advanced",
                    "noise_reduction": True
                },
                AudioQualityMode.ADAPTIVE: {
                    "sample_rate": 16000,
                    "processing_level": "adaptive",
                    "noise_reduction": True
                }
            }

            config = quality_config[quality_mode]

            # Configure components
            if hasattr(self.recorder, 'set_sample_rate'):
                self.recorder.set_sample_rate(config["sample_rate"])

            if hasattr(self.processor, 'set_processing_level'):
                self.processor.set_processing_level(config["processing_level"])

            if hasattr(self.recorder, 'set_noise_reduction'):
                self.recorder.set_noise_reduction(config["noise_reduction"])

            # Trigger quality change event
            self._trigger_event("quality_change", {
                "quality_mode": quality_mode.value,
                "config": config
            })

            self.logger.info(f"Set audio quality mode to {quality_mode.value}")

        except Exception as e:
            self.logger.error(f"Error setting quality mode: {e}")

    def _trigger_event(self, event_type: str, event_data: Dict[str, Any]):
        """Trigger event callbacks."""
        try:
            if event_type in self.event_callbacks:
                for callback in self.event_callbacks[event_type]:
                    try:
                        callback(event_data)
                    except Exception as e:
                        self.logger.error(f"Error in event callback: {e}")
        except Exception as e:
            self.logger.error(f"Error triggering event {event_type}: {e}")

    def add_event_listener(self, event_type: str, callback: Callable[[Dict[str, Any]], None]):
        """Add event listener."""
        if event_type not in self.event_callbacks:
            self.event_callbacks[event_type] = []
        self.event_callbacks[event_type].append(callback)

    def remove_event_listener(self, event_type: str, callback: Callable[[Dict[str, Any]], None]):
        """Remove event listener."""
        if event_type in self.event_callbacks and callback in self.event_callbacks[event_type]:
            self.event_callbacks[event_type].remove(callback)

    def _check_session_timeouts(self):
        """Check for session timeouts."""
        try:
            timeout_threshold = timedelta(
                minutes=self.config.session_timeout_minutes)
            current_time = datetime.now()

            sessions_to_end = []
            for session_id, session in self.active_sessions.items():
                if current_time - session.start_time > timeout_threshold:
                    sessions_to_end.append(session_id)

            for session_id in sessions_to_end:
                self.logger.info(f"Session {session_id} timed out")
                self.end_session(session_id)

        except Exception as e:
            self.logger.error(f"Error checking session timeouts: {e}")

    def _update_performance_stats(self):
        """Update performance statistics."""
        try:
            # Add any performance monitoring logic here
            pass
        except Exception as e:
            self.logger.error(f"Error updating performance stats: {e}")

    def _check_system_health(self):
        """Check overall system health."""
        try:
            # Check component health
            issues = []

            if not hasattr(self, 'recorder') or self.recorder is None:
                issues.append("Audio recorder not available")

            if not hasattr(self, 'tts') or self.tts is None:
                issues.append("TTS system not available")

            if issues:
                self.logger.warning(f"System health issues: {issues}")

        except Exception as e:
            self.logger.error(f"Error checking system health: {e}")

    def _update_avg_processing_time(self, new_time: float):
        """Update average processing time."""
        current_avg = self.performance_stats["average_processing_time"]
        total_recordings = self.performance_stats["total_recordings"]

        if total_recordings == 1:
            self.performance_stats["average_processing_time"] = new_time
        else:
            # Moving average
            self.performance_stats["average_processing_time"] = (
                (current_avg * (total_recordings - 1) + new_time) / total_recordings
            )

    def _save_session_data(self, session: AudioSession):
        """Save session data to storage."""
        try:
            session_data = {
                "session_id": session.session_id,
                "session_type": session.session_type.value,
                "child_id": session.child_id,
                "start_time": session.start_time.isoformat(),
                "end_time": session.end_time.isoformat() if session.end_time else None,
                "total_recordings": session.total_recordings,
                "total_duration": session.total_duration,
                "quality_mode": session.quality_mode.value,
                "metadata": session.metadata
            }

            # Save to file (implement as needed)
            session_file = Path(self.audio_io.temp_dir) / \
                f"session_{session.session_id}.json"
            with open(session_file, 'w') as f:
                json.dump(session_data, f, indent=2)

        except Exception as e:
            self.logger.error(f"Error saving session data: {e}")

    def _cleanup_old_sessions(self):
        """Cleanup old session files."""
        try:
            session_dir = Path(self.audio_io.temp_dir)
            cutoff_time = datetime.now() - timedelta(days=7)

            for session_file in session_dir.glob("session_*.json"):
                try:
                    if datetime.fromtimestamp(session_file.stat().st_mtime) < cutoff_time:
                        session_file.unlink()
                except Exception as e:
                    self.logger.warning(
                        f"Error removing session file {session_file}: {e}")

        except Exception as e:
            self.logger.error(f"Error cleaning up old sessions: {e}")

    def _handle_error(self, event: StateChangeEvent):
        """Handle error state changes."""
        if event.details and "error" in event.details:
            error_msg = event.details['error']
            self.logger.error(f"Audio system error: {error_msg}")

            # Trigger error event
            self._trigger_event(
                "error", {"error": error_msg, "timestamp": datetime.now().isoformat()})

            # Stop any ongoing operations
            self.stop_all()

    def _handle_recording_state(self, event: StateChangeEvent):
        """Handle recording state changes."""
        if event.new_state == AudioState.RECORDING:
            self.logger.debug("Recording state changed to RECORDING")
        elif event.new_state == AudioState.IDLE:
            self.logger.debug("Recording state changed to IDLE")

    def _handle_playback_state(self, event: StateChangeEvent):
        """Handle playback state changes."""
        if event.new_state == AudioState.PLAYING:
            self.logger.debug("Playback state changed to PLAYING")
        elif event.new_state == AudioState.IDLE:
            self.logger.debug("Playback state changed to IDLE")

    def _on_playback_complete(self):
        """Callback function for when TTS playback is complete."""
        self.logger.info("TTS playback complete.")
        state_manager.set_state("playback", AudioState.IDLE)

    def cleanup(self):
        """Clean up all resources and stop background tasks."""
        try:
            self.logger.info("Starting audio manager cleanup")

            # Stop all active operations
            self.stop_all()

            # End all active sessions
            with self._session_lock:
                for session_id in list(self.active_sessions.keys()):
                    self.end_session(session_id)

            # Clean up audio files
            if hasattr(self, 'audio_io'):
                self.audio_io.cleanup_temp_files()

            # Clean up TTS cache
            if hasattr(self, 'tts') and hasattr(self.tts, 'cleanup_cache'):
                self.tts.cleanup_cache()

            # Stop background tasks (they're daemon threads, so they'll stop automatically)

            self.logger.info("Audio manager cleanup completed")

        except Exception as e:
            self.logger.error(f"Error during cleanup: {e}")

    def get_supported_devices(self) -> List[Tuple[int, str]]:
        """Get list of supported audio devices."""
        try:
            if hasattr(self.recorder, 'get_supported_devices'):
                return self.recorder.get_supported_devices()
            else:
                self.logger.warning(
                    "Recorder does not support device enumeration")
                return []
        except Exception as e:
            self.logger.error(f"Error getting supported devices: {e}")
            return []

    def set_input_device(self, device_id: int) -> bool:
        """
        Set audio input device.

        Args:
            device_id: Device ID to set

        Returns:
            Success status
        """
        try:
            if hasattr(self.recorder, 'set_input_device'):
                self.recorder.set_input_device(device_id)
                self.logger.info(f"Set input device to {device_id}")
                return True
            else:
                self.logger.warning(
                    "Recorder does not support device selection")
                return False
        except Exception as e:
            self.logger.error(f"Error setting input device: {e}")
            state_manager.set_error(str(e))
            return False

    def set_output_device(self, device_id: int) -> bool:
        """
        Set audio output device.

        Args:
            device_id: Device ID to set

        Returns:
            Success status
        """
        try:
            if hasattr(self.tts, 'set_output_device'):
                self.tts.set_output_device(device_id)
                self.logger.info(f"Set output device to {device_id}")
                return True
            else:
                self.logger.warning(
                    "TTS system does not support device selection")
                return False
        except Exception as e:
            self.logger.error(f"Error setting output device: {e}")
            state_manager.set_error(str(e))
            return False

    def test_audio_system(self) -> Dict[str, Any]:
        """
        Comprehensive audio system test.

        Returns:
            Test results dictionary
        """
        test_results = {
            "overall_status": "unknown",
            "tests": {},
            "timestamp": datetime.now().isoformat()
        }

        try:
            self.logger.info("Starting comprehensive audio system test")

            # Test 1: Component initialization
            test_results["tests"]["component_init"] = {
                "recorder": hasattr(self, 'recorder') and self.recorder is not None,
                "processor": hasattr(self, 'processor') and self.processor is not None,
                "audio_io": hasattr(self, 'audio_io') and self.audio_io is not None,
                "tts": hasattr(self, 'tts') and self.tts is not None
            }

            # Test 2: Device availability
            try:
                devices = self.get_supported_devices()
                test_results["tests"]["device_availability"] = {
                    "status": len(devices) > 0,
                    "device_count": len(devices),
                    "devices": devices[:3]  # First 3 devices for brevity
                }
            except Exception as e:
                test_results["tests"]["device_availability"] = {
                    "status": False,
                    "error": str(e)
                }

            # Test 3: Audio playback
            try:
                self.logger.info("Testing audio playback...")
                test_tone = np.sin(2 * np.pi * 440 *
                                   np.arange(8000) / 16000).astype(np.float32)
                playback_success = self.play_audio(test_tone)
                test_results["tests"]["playback"] = {
                    "status": playback_success,
                    "test_duration": 0.5
                }
            except Exception as e:
                test_results["tests"]["playback"] = {
                    "status": False,
                    "error": str(e)
                }

            # Test 4: TTS functionality
            try:
                self.logger.info("Testing TTS system...")
                tts_success = self.speak("Audio system test", cache=False)
                test_results["tests"]["tts"] = {
                    "status": tts_success,
                    "test_text": "Audio system test"
                }
            except Exception as e:
                test_results["tests"]["tts"] = {
                    "status": False,
                    "error": str(e)
                }

            # Test 5: Recording capability (if available)
            try:
                if hasattr(self.recorder, 'test_recording'):
                    recording_test = self.recorder.test_recording()
                    test_results["tests"]["recording"] = {
                        "status": recording_test,
                        "test_duration": 1.0
                    }
                else:
                    test_results["tests"]["recording"] = {
                        "status": "skipped",
                        "reason": "Test recording method not available"
                    }
            except Exception as e:
                test_results["tests"]["recording"] = {
                    "status": False,
                    "error": str(e)
                }

            # Test 6: Session management
            try:
                test_session_id = self.start_session(
                    "test_child", AudioSessionType.SYSTEM_TEST)
                session_info = self.get_session_info(test_session_id)
                session_end_success = self.end_session(test_session_id)

                test_results["tests"]["session_management"] = {
                    "status": session_info is not None and session_end_success,
                    "session_created": session_info is not None,
                    "session_ended": session_end_success
                }
            except Exception as e:
                test_results["tests"]["session_management"] = {
                    "status": False,
                    "error": str(e)
                }

            # Determine overall status
            test_statuses = [
                test.get("status", False)
                for test in test_results["tests"].values()
                if isinstance(test.get("status"), bool)
            ]

            if all(test_statuses):
                test_results["overall_status"] = "pass"
            elif any(test_statuses):
                test_results["overall_status"] = "partial"
            else:
                test_results["overall_status"] = "fail"

            self.logger.info(
                f"Audio system test completed: {test_results['overall_status']}")

        except Exception as e:
            self.logger.error(f"Audio system test failed: {e}")
            test_results["overall_status"] = "error"
            test_results["error"] = str(e)
            state_manager.set_error(str(e))

        return test_results

    def get_available_languages(self) -> List[str]:
        """Get list of available TTS languages."""
        try:
            if hasattr(self.tts, 'get_available_languages'):
                return self.tts.get_available_languages()
            else:
                # Return default languages
                return ["en", "es", "fr", "de", "it", "pt", "zh", "ja", "ko", "ar"]
        except Exception as e:
            self.logger.error(f"Error getting available languages: {e}")
            return ["en"]  # Fallback to English

    def update_configuration(self, new_config: Dict[str, Any]) -> bool:
        """
        Update audio system configuration.

        Args:
            new_config: Configuration updates

        Returns:
            Success status
        """
        try:
            # Update configuration attributes
            for key, value in new_config.items():
                if hasattr(self.config, key):
                    setattr(self.config, key, value)
                    self.logger.info(f"Updated config: {key} = {value}")

            # Reconfigure components
            self._configure_components()

            return True

        except Exception as e:
            self.logger.error(f"Error updating configuration: {e}")
            return False

    def export_session_data(
        self,
        session_id: str,
        export_format: str = "json"
    ) -> Optional[str]:
        """
        Export session data to file.

        Args:
            session_id: Session to export
            export_format: Export format (json, csv)

        Returns:
            Export file path or None
        """
        try:
            if session_id not in self.active_sessions:
                self.logger.error(f"Session {session_id} not found")
                return None

            session = self.active_sessions[session_id]

            # Prepare export data
            export_data = {
                "session_info": self.get_session_info(session_id),
                "performance_stats": self.performance_stats.copy(),
                "export_timestamp": datetime.now().isoformat()
            }

            # Create export filename
            export_filename = f"session_export_{session_id}_{int(time.time())}.{export_format}"
            export_path = Path(self.audio_io.temp_dir) / export_filename

            # Export based on format
            if export_format == "json":
                with open(export_path, 'w') as f:
                    json.dump(export_data, f, indent=2)
            else:
                self.logger.error(
                    f"Unsupported export format: {export_format}")
                return None

            self.logger.info(f"Session data exported to {export_path}")
            return str(export_path)

        except Exception as e:
            self.logger.error(f"Error exporting session data: {e}")
            return None

    def emergency_stop(self):
        """Emergency stop all audio operations immediately."""
        try:
            self.logger.warning("EMERGENCY STOP initiated")

            # Force stop all operations
            if hasattr(self, 'recorder') and self.recorder:
                try:
                    self.recorder.emergency_stop()
                except:
                    pass

            if hasattr(self, 'tts') and self.tts:
                try:
                    self.tts.emergency_stop()
                except:
                    pass

            # Clear all sessions
            with self._session_lock:
                self.active_sessions.clear()
                self.current_session = None

            # Set error state
            state_manager.set_error("Emergency stop activated")

            self.logger.warning("Emergency stop completed")

        except Exception as e:
            self.logger.error(f"Error during emergency stop: {e}")

    def add_state_observer(
        self,
        event_type: str,
        callback: Callable[[StateChangeEvent], None]
    ):
        """Add state change observer."""
        try:
            state_manager.add_observer(event_type, callback)
        except Exception as e:
            self.logger.error(f"Error adding state observer: {e}")

    def remove_state_observer(
        self,
        event_type: str,
        callback: Callable[[StateChangeEvent], None]
    ):
        """Remove state change observer."""
        try:
            state_manager.remove_observer(event_type, callback)
        except Exception as e:
            self.logger.error(f"Error removing state observer: {e}")

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit with cleanup."""
        self.cleanup()


# Convenience functions for easy access

def create_audio_manager(config: Optional[AudioSystemConfig] = None) -> AudioManager:
    """
    Create and configure audio manager instance.

    Args:
        config: Optional configuration

    Returns:
        AudioManager instance
    """
    return AudioManager(config)


def get_default_config() -> AudioSystemConfig:
    """Get default audio system configuration."""
    return AudioSystemConfig()


def create_child_safe_config() -> AudioSystemConfig:
    """Create configuration optimized for child safety."""
    config = AudioSystemConfig()
    config.child_safe_mode = True
    config.max_record_duration = 30  # Shorter recordings
    config.emergency_override = True
    config.volume_level = 0.7  # Moderate volume
    config.noise_reduction_enabled = True
    config.voice_activity_detection = True
    return config


def create_high_quality_config() -> AudioSystemConfig:
    """Create configuration for high-quality audio."""
    config = AudioSystemConfig()
    config.auto_process_audio = True
    config.noise_reduction_enabled = True
    config.adaptive_quality = True
    config.max_record_duration = 60
    config.volume_level = 0.9
    return config


# Global audio manager instance (singleton pattern)
_global_audio_manager: Optional[AudioManager] = None


def get_audio_manager(config: Optional[AudioSystemConfig] = None) -> AudioManager:
    """
    Get global audio manager instance (singleton).

    Args:
        config: Configuration for first-time initialization

    Returns:
        Global AudioManager instance
    """
    global _global_audio_manager

    if _global_audio_manager is None:
        _global_audio_manager = AudioManager(config)

    return _global_audio_manager


def shutdown_audio_manager():
    """Shutdown global audio manager."""
    global _global_audio_manager

    if _global_audio_manager is not None:
        _global_audio_manager.cleanup()
        _global_audio_manager = None


# Legacy compatibility
audio_manager = get_audio_manager()
