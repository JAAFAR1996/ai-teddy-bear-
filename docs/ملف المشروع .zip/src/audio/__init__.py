"""Audio system module.

This module provides a complete audio processing system with capabilities for:
- Audio recording and playback
- Text-to-speech conversion
- Audio file I/O operations
- Audio signal processing
- State management

The system follows clean architecture principles with clear separation of concerns
and robust error handling throughout.

Example usage:
    from audio import audio_manager
    
    # Record audio
    audio_data = audio_manager.record(duration=5)
    
    # Play audio
    audio_manager.play_audio(audio_data)
    
    # Text-to-speech
    audio_manager.speak("Hello world")
"""

from .audio_manager import audio_manager, AudioManager
from .audio_recorder import AudioRecorder
from .audio_processing import (
    AudioProcessor,
    process_audio,
    normalize_volume,
    detect_silence,
    trim_silence,
    get_audio_stats
)
from .audio_io import (
    AudioIO,
    cleanup_temp_files,
    get_audio_files,
    get_audio_duration,
    get_audio_format
)
from .tts_playback import TTSPlayback, cleanup_tts_cache
from .state_manager import (
    state_manager,
    AudioState,
    StateChangeEvent,
    StateManager
)

__all__ = [
    # Main interface
    'audio_manager',
    'AudioManager',
    
    # Core components
    'AudioRecorder',
    'AudioProcessor',
    'AudioIO',
    'TTSPlayback',
    
    # State management
    'state_manager',
    'AudioState',
    'StateChangeEvent',
    'StateManager',
    
    # Audio processing functions
    'process_audio',
    'normalize_volume',
    'detect_silence',
    'trim_silence',
    'get_audio_stats',
    
    # File operations
    'cleanup_temp_files',
    'cleanup_tts_cache',
    'get_audio_files',
    'get_audio_duration',
    'get_audio_format'
]

# Version info
__version__ = '1.0.0'
__author__ = 'Audio System Team'
__license__ = 'MIT'
