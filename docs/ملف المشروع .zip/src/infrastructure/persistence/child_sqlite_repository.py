import os
import sqlite3
import json
import uuid
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta

from src.infrastructure.persistence.base_sqlite_repository import BaseSQLiteRepository
from src.domain.entities.child import Child
from src.domain.repositories.child_repository import ChildRepository
from src.domain.repositories.base import SearchCriteria, QueryOptions, SortOrder


class ChildSQLiteRepository(BaseSQLiteRepository[Child, int], ChildRepository):

    """
    SQLite implementation of Child Repository
    """
    
    def __init__(
        self, session_factory,
        db_path: str = os.path.join(
            os.path.dirname(__file__), 
            '..', 
            '..', 
            '..', 
            'data', 
            'teddyai.db'
        )
    ):
      
        """
        Initialize Child SQLite Repository
        
        Args:
            db_path (str): Path to SQLite database
        """
        self.session_factory = session_factory
        # Ensure data directory exists
        data_dir = os.path.dirname(db_path)
        if not os.path.exists(data_dir):
            os.makedirs(data_dir, exist_ok=True)
            
        # Create connection
        connection = sqlite3.connect(db_path, check_same_thread=False)
        
        super().__init__(
            connection=connection,
            table_name='children', 
            entity_class=Child
        )
        
    async def initialize(self):
        # لا تفعل شيئاً هنا
        pass
    
    def _get_table_schema(self) -> str:
        """
        Get the CREATE TABLE SQL statement for children table
        
        Returns:
            str: SQL CREATE TABLE statement
        """
        return '''
            CREATE TABLE IF NOT EXISTS children (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                age INTEGER NOT NULL,
                date_of_birth DATE,
                gender TEXT,
                interests TEXT,
                personality_traits TEXT,
                learning_preferences TEXT,
                communication_style TEXT,
                max_daily_interaction_time INTEGER DEFAULT 3600,
                allowed_topics TEXT,
                restricted_topics TEXT,
                language_preference TEXT DEFAULT 'en',
                cultural_background TEXT,
                parental_controls TEXT,
                emergency_contacts TEXT,
                medical_notes TEXT,
                educational_level TEXT,
                special_needs TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_interaction DATETIME,
                total_interaction_time INTEGER DEFAULT 0,
                is_active BOOLEAN DEFAULT 1,
                privacy_settings TEXT,
                custom_settings TEXT
            )
        '''
    
    def _serialize_child_for_db(self, child: Child) -> Dict[str, Any]:
        """
        Serialize child entity for database storage
        
        Args:
            child: Child entity
            
        Returns:
            Dictionary for database storage
        """
        data = child.dict() if hasattr(child, 'dict') else child.__dict__.copy()
        
        # Generate ID if not present
        if not data.get('id'):
            data['id'] = str(uuid.uuid4())
        
        # Serialize complex fields to JSON
        json_fields = [
            'interests', 'personality_traits', 'learning_preferences',
            'allowed_topics', 'restricted_topics', 'parental_controls',
            'emergency_contacts', 'privacy_settings', 'custom_settings'
        ]
        
        for field in json_fields:
            if field in data and data[field] is not None:
                data[field] = json.dumps(data[field])
        
        # Handle datetime fields
        if 'date_of_birth' in data and isinstance(data['date_of_birth'], datetime):
            data['date_of_birth'] = data['date_of_birth'].date().isoformat()
        
        # Set updated_at timestamp
        data['updated_at'] = datetime.now().isoformat()
        
        return data
    def add(self, *args, **kwargs):
        raise NotImplementedError

    def aggregate(self, *args, **kwargs):
        raise NotImplementedError

    def find_by_learning_level(self, *args, **kwargs):
        raise NotImplementedError

    def find_by_parent(self, *args, **kwargs):
        raise NotImplementedError

    def get(self, *args, **kwargs):
        raise NotImplementedError

    def get_inactive_children(self, *args, **kwargs):
        raise NotImplementedError

    def _deserialize_child_from_db(self, data: Dict[str, Any]) -> Child:
        """
        Deserialize child data from database
        
        Args:
            data: Database row data
            
        Returns:
            Child entity
        """
        # Parse JSON fields
        json_fields = [
            'interests', 'personality_traits', 'learning_preferences',
            'allowed_topics', 'restricted_topics', 'parental_controls',
            'emergency_contacts', 'privacy_settings', 'custom_settings'
        ]
        
        for field in json_fields:
            if field in data and data[field]:
                try:
                    data[field] = json.loads(data[field])
                except (json.JSONDecodeError, TypeError):
                    data[field] = [] if field.endswith('s') else {}
            else:
                data[field] = [] if field.endswith('s') else {}
        
        # Parse datetime fields
        datetime_fields = ['created_at', 'updated_at', 'last_interaction']
        for field in datetime_fields:
            if field in data and data[field]:
                try:
                    data[field] = datetime.fromisoformat(data[field])
                except (ValueError, TypeError):
                    data[field] = None
        
        # Parse date fields
        if 'date_of_birth' in data and data['date_of_birth']:
            try:
                data['date_of_birth'] = datetime.fromisoformat(data['date_of_birth']).date()
            except (ValueError, TypeError):
                data['date_of_birth'] = None
        
        # Convert boolean fields
        if 'is_active' in data:
            data['is_active'] = bool(data['is_active'])
        
        return Child(**data)
    
    async def create(self, child: Child) -> Child:
        """
        Create a new child profile
        
        Args:
            child: Child entity to create
            
        Returns:
            Created child with assigned ID
        """
        try:
            with self.transaction() as cursor:
                data = self._serialize_child_for_db(child)
                
                columns = ', '.join(data.keys())
                placeholders = ', '.join(['?' for _ in data])
                sql = f"INSERT INTO {self.table_name} ({columns}) VALUES ({placeholders})"
                
                cursor.execute(sql, list(data.values()))
                
                # Assign ID if not already present
                if not child.id:
                    child.id = data['id']
                
                return child
                
        except sqlite3.Error as e:
            self.logger.error(f"Error creating child: {e}")
            raise
    
    async def get_by_id(self, child_id: str) -> Optional[Child]:
        """
        Retrieve child by ID
        
        Args:
            child_id: Child's unique identifier
            
        Returns:
            Child entity or None
        """
        try:
            cursor = self._connection.cursor()
            sql = f"SELECT * FROM {self.table_name} WHERE id = ? AND is_active = 1"
            cursor.execute(sql, (child_id,))
            
            row = cursor.fetchone()
            if row:
                return self._deserialize_child_from_db(dict(row))
            return None
            
        except sqlite3.Error as e:
            self.logger.error(f"Error retrieving child {child_id}: {e}")
            raise
    
    async def update(self, child: Child) -> Child:
        """
        Update existing child profile
        
        Args:
            child: Child entity to update
            
        Returns:
            Updated child
        """
        try:
            with self.transaction() as cursor:
                data = self._serialize_child_for_db(child)
                
                if 'id' not in data or not data['id']:
                    raise ValueError("Child must have an ID for update")
                
                # Prepare update SQL
                update_fields = [f"{k} = ?" for k in data.keys() if k != 'id']
                update_values = [v for k, v in data.items() if k != 'id']
                update_values.append(data['id'])
                
                sql = f"UPDATE {self.table_name} SET {', '.join(update_fields)} WHERE id = ?"
                
                cursor.execute(sql, update_values)
                
                if cursor.rowcount == 0:
                    raise ValueError(f"No child found with ID {data['id']}")
                
                return child
                
        except sqlite3.Error as e:
            self.logger.error(f"Error updating child: {e}")
            raise
    
    async def delete(self, child_id: str) -> bool:
        """
        Soft delete child (mark as inactive)
        
        Args:
            child_id: Child's unique identifier
            
        Returns:
            True if deleted successfully
        """
        try:
            with self.transaction() as cursor:
                sql = f"UPDATE {self.table_name} SET is_active = 0, updated_at = ? WHERE id = ?"
                cursor.execute(sql, (datetime.now().isoformat(), child_id))
                return cursor.rowcount > 0
                
        except sqlite3.Error as e:
            self.logger.error(f"Error deleting child {child_id}: {e}")
            raise
    
    async def list(self, options: Optional[QueryOptions] = None) -> List[Child]:
        """
        List active children with optional filtering and sorting
        
        Args:
            options: Query options
            
        Returns:
            List of children
        """
        try:
            cursor = self._connection.cursor()
            sql = f"SELECT * FROM {self.table_name} WHERE is_active = 1"
            params = []
            
            # Apply additional filters
            if options and hasattr(options, 'filters') and options.filters:
                filter_conditions = []
                for key, value in options.filters.items():
                    filter_conditions.append(f"{key} = ?")
                    params.append(self._serialize_for_db(value))
                
                if filter_conditions:
                    sql += " AND " + " AND ".join(filter_conditions)
            
            # Apply sorting
            if options and hasattr(options, 'sort_by') and options.sort_by:
                order = "DESC" if hasattr(options, 'sort_order') and options.sort_order == SortOrder.DESC else "ASC"
                sql += f" ORDER BY {options.sort_by} {order}"
            
            # Apply pagination
            if options and hasattr(options, 'limit') and options.limit:
                sql += f" LIMIT {options.limit}"
                
            if options and hasattr(options, 'offset') and options.offset:
                sql += f" OFFSET {options.offset}"
            
            cursor.execute(sql, params)
            rows = cursor.fetchall()
            
            return [self._deserialize_child_from_db(dict(row)) for row in rows]
            
        except sqlite3.Error as e:
            self.logger.error(f"Error listing children: {e}")
            raise
    
    # Child-specific repository methods
    
    async def find_by_name(self, name: str) -> Optional[Child]:
        """
        Find a child by their name
        
        Args:
            name: Child's name
        
        Returns:
            Matching child profile or None
        """
        try:
            cursor = self._connection.cursor()
            sql = f"SELECT * FROM {self.table_name} WHERE name = ? AND is_active = 1"
            cursor.execute(sql, (name,))
            
            row = cursor.fetchone()
            if row:
                return self._deserialize_child_from_db(dict(row))
            return None
            
        except sqlite3.Error as e:
            self.logger.error(f"Error finding child by name: {e}")
            raise
    
    async def find_by_age_range(self, min_age: int, max_age: int) -> List[Child]:
        """
        Find children within a specific age range
        
        Args:
            min_age: Minimum age (inclusive)
            max_age: Maximum age (inclusive)
        
        Returns:
            List of children in the specified age range
        """
        try:
            cursor = self._connection.cursor()
            sql = f"SELECT * FROM {self.table_name} WHERE age BETWEEN ? AND ? AND is_active = 1"
            cursor.execute(sql, (min_age, max_age))
            
            rows = cursor.fetchall()
            return [self._deserialize_child_from_db(dict(row)) for row in rows]
            
        except sqlite3.Error as e:
            self.logger.error(f"Error finding children by age range: {e}")
            raise
    
    async def find_by_interests(self, interests: List[str], match_all: bool = False) -> List[Child]:
        """
        Find children with matching interests
        
        Args:
            interests: List of interests to match
            match_all: Whether to match all interests or any
        
        Returns:
            List of children with matching interests
        """
        try:
            cursor = self._connection.cursor()
            
            if match_all:
                # Use JSON functions for exact matching
                conditions = []
                params = []
                for interest in interests:
                    conditions.append("JSON_EXTRACT(interests, '$') LIKE ?")
                    params.append(f'%"{interest}"%')
                
                sql = f"SELECT * FROM {self.table_name} WHERE {' AND '.join(conditions)} AND is_active = 1"
            else:
                # Match any interest
                conditions = []
                params = []
                for interest in interests:
                    conditions.append("JSON_EXTRACT(interests, '$') LIKE ?")
                    params.append(f'%"{interest}"%')
                
                sql = f"SELECT * FROM {self.table_name} WHERE ({' OR '.join(conditions)}) AND is_active = 1"
            
            cursor.execute(sql, params)
            rows = cursor.fetchall()
            
            return [self._deserialize_child_from_db(dict(row)) for row in rows]
            
        except sqlite3.Error as e:
            self.logger.error(f"Error finding children by interests: {e}")
            raise
    
    async def find_by_language(self, language: str) -> List[Child]:
        """
        Find children by language preference
        
        Args:
            language: Language code (e.g., 'en', 'es', 'fr')
        
        Returns:
            List of children with matching language preference
        """
        try:
            cursor = self._connection.cursor()
            sql = f"SELECT * FROM {self.table_name} WHERE language_preference = ? AND is_active = 1"
            cursor.execute(sql, (language,))
            
            rows = cursor.fetchall()
            return [self._deserialize_child_from_db(dict(row)) for row in rows]
            
        except sqlite3.Error as e:
            self.logger.error(f"Error finding children by language: {e}")
            raise
    
    async def get_children_with_recent_interactions(self, days: int = 7) -> List[Child]:
        """
        Get children who have had interactions within the last N days
        
        Args:
            days: Number of days to look back
        
        Returns:
            Children with recent interactions
        """
        cutoff_date = datetime.now() - timedelta(days=days)
        
        try:
            cursor = self._connection.cursor()
            sql = f"SELECT * FROM {self.table_name} WHERE last_interaction >= ? AND is_active = 1"
            cursor.execute(sql, (cutoff_date.isoformat(),))
            
            rows = cursor.fetchall()
            return [self._deserialize_child_from_db(dict(row)) for row in rows]
            
        except sqlite3.Error as e:
            self.logger.error(f"Error finding children with recent interactions: {e}")
            raise
    
    async def get_children_by_max_interaction_time(self, max_time: int) -> List[Child]:
        """
        Get children with maximum daily interaction time less than or equal to specified time
        
        Args:
            max_time: Maximum daily interaction time in seconds
        
        Returns:
            Children matching the interaction time criteria
        """
        try:
            cursor = self._connection.cursor()
            sql = f"SELECT * FROM {self.table_name} WHERE max_daily_interaction_time <= ? AND is_active = 1"
            cursor.execute(sql, (max_time,))
            
            rows = cursor.fetchall()
            return [self._deserialize_child_from_db(dict(row)) for row in rows]
            
        except sqlite3.Error as e:
            self.logger.error(f"Error finding children by max interaction time: {e}")
            raise
    
    async def get_children_by_age_group(self, age_group: str) -> List[Child]:
        """
        Get children by predefined age groups
        
        Args:
            age_group: Age group ('preschool', 'elementary', 'middle', 'high')
        
        Returns:
            Children in the specified age group
        """
        age_ranges = {
            'preschool': (3, 5),
            'elementary': (6, 11),
            'middle': (12, 14),
            'high': (15, 18)
        }
        
        if age_group not in age_ranges:
            raise ValueError(f"Invalid age group: {age_group}")
        
        min_age, max_age = age_ranges[age_group]
        return await self.find_by_age_range(min_age, max_age)
    
    async def update_last_interaction(self, child_id: str) -> bool:
        """
        Update last interaction timestamp for a child
        
        Args:
            child_id: Child's unique identifier
        
        Returns:
            True if updated successfully
        """
        try:
            with self.transaction() as cursor:
                sql = f"UPDATE {self.table_name} SET last_interaction = ?, updated_at = ? WHERE id = ? AND is_active = 1"
                now = datetime.now().isoformat()
                cursor.execute(sql, (now, now, child_id))
                return cursor.rowcount > 0
                
        except sqlite3.Error as e:
            self.logger.error(f"Error updating last interaction: {e}")
            raise
    
    async def update_interaction_time(self, child_id: str, additional_time: int) -> bool:
        """
        Add to total interaction time for a child
        
        Args:
            child_id: Child's unique identifier
            additional_time: Additional interaction time in seconds
        
        Returns:
            True if updated successfully
        """
        try:
            with self.transaction() as cursor:
                sql = f"""
                    UPDATE {self.table_name} 
                    SET total_interaction_time = total_interaction_time + ?, 
                        last_interaction = ?,
                        updated_at = ? 
                    WHERE id = ? AND is_active = 1
                """
                now = datetime.now().isoformat()
                cursor.execute(sql, (additional_time, now, now, child_id))
                return cursor.rowcount > 0
                
        except sqlite3.Error as e:
            self.logger.error(f"Error updating interaction time: {e}")
            raise
    
    async def reset_daily_interaction_time(self) -> int:
        """
        Reset daily interaction tracking for all children
        
        Returns:
            Number of children updated
        """
        try:
            with self.transaction() as cursor:
                # Reset daily interaction tracking fields
                sql = f"""
                    UPDATE {self.table_name} 
                    SET total_interaction_time = 0,
                        updated_at = ?
                    WHERE is_active = 1
                """
                cursor.execute(sql, (datetime.now().isoformat(),))
                return cursor.rowcount
                
        except sqlite3.Error as e:
            self.logger.error(f"Error resetting daily interaction time: {e}")
            raise
    
    async def get_children_over_time_limit(self) -> List[Child]:
        """
        Get children who have exceeded their daily interaction time limit
        
        Returns:
            List of children over their time limit
        """
        try:
            cursor = self._connection.cursor()
            sql = f"""
                SELECT * FROM {self.table_name} 
                WHERE total_interaction_time >= max_daily_interaction_time 
                AND is_active = 1
            """
            cursor.execute(sql)
            
            rows = cursor.fetchall()
            return [self._deserialize_child_from_db(dict(row)) for row in rows]
            
        except sqlite3.Error as e:
            self.logger.error(f"Error finding children over time limit: {e}")
            raise
    
    async def search_children(self, query: str) -> List[Child]:
        """
        Search children by name, interests, or other text fields
        
        Args:
            query: Search query
        
        Returns:
            List of matching children
        """
        try:
            cursor = self._connection.cursor()
            sql = f"""
                SELECT * FROM {self.table_name} 
                WHERE (
                    name LIKE ? OR 
                    interests LIKE ? OR 
                    cultural_background LIKE ? OR
                    educational_level LIKE ?
                ) AND is_active = 1
            """
            search_term = f"%{query}%"
            cursor.execute(sql, (search_term, search_term, search_term, search_term))
            
            rows = cursor.fetchall()
            return [self._deserialize_child_from_db(dict(row)) for row in rows]
            
        except sqlite3.Error as e:
            self.logger.error(f"Error searching children: {e}")
            raise
    
    async def get_children_statistics(self) -> Dict[str, Any]:
        """
        Get statistical information about children in the database
        
        Returns:
            Dictionary with various statistics
        """
        try:
            cursor = self._connection.cursor()
            
            # Total count
            cursor.execute(f"SELECT COUNT(*) FROM {self.table_name} WHERE is_active = 1")
            total_count = cursor.fetchone()[0]
            
            # Age distribution
            cursor.execute(f"""
                SELECT 
                    MIN(age) as min_age,
                    MAX(age) as max_age,
                    AVG(age) as avg_age
                FROM {self.table_name} 
                WHERE is_active = 1
            """)
            age_stats = cursor.fetchone()
            
            # Language distribution
            cursor.execute(f"""
                SELECT language_preference, COUNT(*) as count
                FROM {self.table_name} 
                WHERE is_active = 1
                GROUP BY language_preference
            """)
            language_distribution = dict(cursor.fetchall())
            
            # Recent activity
            cutoff_date = datetime.now() - timedelta(days=7)
            cursor.execute(f"""
                SELECT COUNT(*) FROM {self.table_name} 
                WHERE last_interaction >= ? AND is_active = 1
            """, (cutoff_date.isoformat(),))
            recent_activity_count = cursor.fetchone()[0]
            
            return {
                'total_children': total_count,
                'age_statistics': {
                    'min_age': age_stats[0] if age_stats[0] else 0,
                    'max_age': age_stats[1] if age_stats[1] else 0,
                    'average_age': round(age_stats[2], 1) if age_stats[2] else 0
                },
                'language_distribution': language_distribution,
                'recent_activity': {
                    'children_active_last_7_days': recent_activity_count,
                    'activity_percentage': round((recent_activity_count / total_count * 100), 1) if total_count > 0 else 0
                }
            }
            
        except sqlite3.Error as e:
            self.logger.error(f"Error getting children statistics: {e}")
            raise
    
    async def backup_child_data(self, child_id: str) -> Dict[str, Any]:
        """
        Create a backup of all child data
        
        Args:
            child_id: Child's unique identifier
        
        Returns:
            Complete child data backup
        """
        child = await self.get_by_id(child_id)
        if not child:
            raise ValueError(f"Child with ID {child_id} not found")
        
        return {
            'child_profile': child.dict() if hasattr(child, 'dict') else child.__dict__,
            'backup_timestamp': datetime.now().isoformat(),
            'backup_version': '1.0'
        }
    
    async def restore_child_data(self, backup_data: Dict[str, Any]) -> Child:
        """
        Restore child data from backup
        
        Args:
            backup_data: Backup data dictionary
        
        Returns:
            Restored child entity
        """
        child_data = backup_data['child_profile']
        child = Child(**child_data)
        
        # Update or create the child
        existing_child = await self.get_by_id(child.id)
        if existing_child:
            return await self.update(child)
        else:
            return await self.create(child)