"""
Dependency Injection Container - Production Ready 2025
Thread-safe container with proper circular dependency handling
"""

import asyncio
from typing import Dict, Any, Optional, Type, TypeVar, Callable
from datetime import datetime
import threading
from contextlib import asynccontextmanager
import structlog
from prometheus_client import Gauge

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
import redis.asyncio as redis

from src.infrastructure.config import get_settings, Settings
from src.application.services.service_registry import ServiceRegistry
from dependency_injector import containers, providers, resources


# Metrics
container_health_gauge = Gauge(
    'teddy_container_health',
    'Container component health status',
    ['component']
)

T = TypeVar('T')


class ServiceNotFoundError(Exception):
    """Raised when a requested service is not found"""
    pass


class ContainerNotInitializedError(Exception):
    """Raised when container is used before initialization"""
    pass


class AppContainer(containers.DeclarativeContainer):
    wiring_config = containers.WiringConfiguration(packages=[
        "src.application.services",
        "src.application",
        "src.infrastructure",
    ])

    config = providers.Configuration()

    # قاعدة البيانات كـ Resource (تدعم async وcleanup تلقائي)
    db_engine = providers.Resource(
        create_async_engine,
        db_url=config.db.url,
        echo=config.db.echo,
        pool_size=config.db.pool_size,
        max_overflow=config.db.max_overflow,
        pool_timeout=30,
        pool_recycle=3600,
        pool_pre_ping=True
    )

    db_session_factory = providers.Singleton(
        async_sessionmaker,
        bind=db_engine,
        class_=AsyncSession,
        expire_on_commit=False
    )

    # Redis كـ Resource
    redis_client = providers.Resource(
        redis.from_url,
        url=config.redis.url,
        encoding='utf-8',
        decode_responses=True,
        socket_connect_timeout=5,
        socket_timeout=5,
        retry_on_timeout=True,
        health_check_interval=30,
        max_connections=50
    )

    # الخدمات (مثال: AIService)
    ai_service = providers.Singleton(
        lambda: __import__("src.application.services.ai_service", fromlist=["AIService"]).AIService,
        config=config,
        db_session_factory=db_session_factory,
        redis_client=redis_client
    )

    # SystemOrchestrator كـ Singleton (لا استيراد دائري)
    system_orchestrator = providers.Singleton(
        lambda: __import__("src.application.system_orchestrator", fromlist=["SystemOrchestrator"]).SystemOrchestrator,
        registry=ai_service,
        config=config
    )

    # ... سجل بقية الخدمات بنفس النمط ...


class DependencyContainer:
    """
    Thread-safe dependency injection container with lazy loading
    """
    
    _instance: Optional['DependencyContainer'] = None
    _lock = threading.Lock()
    
    def __new__(cls) -> 'DependencyContainer':
        """Ensure singleton instance with thread safety"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        """Initialize container (only runs once due to singleton)"""
        if hasattr(self, '_initialized_flag'):
            return
            
        self._initialized_flag = False
        self._initializing = False
        self._init_lock = asyncio.Lock()
        self.logger = structlog.get_logger()
        
        # Configuration
        self.settings: Optional[Settings] = None
        
        # Database components
        self._engine: Optional[Any] = None
        self._session_factory: Optional[async_sessionmaker] = None
        self._redis_client: Optional[redis.Redis] = None
        
        # Service registry for managing services
        self._registry: Optional[ServiceRegistry] = None
        
        # Repository instances
        self._repositories: Dict[str, Any] = {}
        
        # Service factory functions for lazy loading
        self._service_factories: Dict[Type, Callable] = {}
        
        # Service instances cache
        self._services: Dict[Type, Any] = {}
        
        # Health status
        self._health_status: Dict[str, bool] = {
            'database': False,
            'redis': False,
            'services': False
        }
    
    async def initialize(self, settings: Optional[Settings] = None) -> None:
        """
        Initialize container with configuration
        Thread-safe initialization with proper error handling
        """
        async with self._init_lock:
            if self._initialized_flag:
                return
                
            if self._initializing:
                # Wait for ongoing initialization
                while self._initializing:
                    await asyncio.sleep(0.1)
                return
                
            self._initializing = True
            
            try:
                self.logger.info("Initializing dependency container")
                
                # Load settings
                self.settings = settings or get_settings()
                
                # Initialize service registry
                self._registry = ServiceRegistry()
                await self._registry.initialize()
                
                # Initialize database
                await self._init_database()
                
                # Initialize Redis
                await self._init_redis()
                
                # Register service factories
                self._register_service_factories()
                
                # Initialize core services
                await self._init_core_services()
                
                self._initialized_flag = True
                self._health_status['services'] = True
                
                self.logger.info("Container initialization complete")
                
            except Exception as e:
                self.logger.error(f"Container initialization failed: {e}", exc_info=True)
                self._initialized_flag = False
                raise
            finally:
                self._initializing = False
    
    async def _init_database(self) -> None:
        """Initialize database with proper async support"""
        try:
            db_url = self.settings.database_url
            
            # Convert to async URL
            if db_url.startswith('sqlite:'):
                db_url = db_url.replace('sqlite:', 'sqlite+aiosqlite:')
            elif db_url.startswith('postgresql:'):
                db_url = db_url.replace('postgresql:', 'postgresql+asyncpg:')
                
            # Create engine with optimized settings
            self._engine = create_async_engine(
                db_url,
                echo=self.settings.debug,
                pool_size=self.settings.db_pool_size,
                max_overflow=self.settings.db_max_overflow,
                pool_timeout=30,
                pool_recycle=3600,
                pool_pre_ping=True  # Verify connections before use
            )
            
            # Create session factory
            self._session_factory = async_sessionmaker(
                self._engine,
                class_=AsyncSession,
                expire_on_commit=False
            )
            
            # Test connection
            async with self._engine.begin() as conn:
                await conn.run_sync(lambda c: c.execute("SELECT 1"))
                
            self._health_status['database'] = True
            container_health_gauge.labels(component='database').set(1)
            
            self.logger.info("Database initialized successfully")
            
        except Exception as e:
            self._health_status['database'] = False
            container_health_gauge.labels(component='database').set(0)
            self.logger.error(f"Database initialization failed: {e}")
            raise
    
    async def _init_redis(self) -> None:
        """Initialize Redis with proper error handling"""
        redis_url = self.settings.redis_url
        
        if not redis_url:
            self.logger.warning("Redis URL not configured, skipping Redis initialization")
            return
            
        try:
            # Create Redis client with connection pool
            self._redis_client = redis.Redis.from_url(
                redis_url,
                encoding='utf-8',
                decode_responses=True,
                socket_connect_timeout=5,
                socket_timeout=5,
                retry_on_timeout=True,
                health_check_interval=30,
                max_connections=50
            )
            
            # Test connection
            await self._redis_client.ping()
            
            self._health_status['redis'] = True
            container_health_gauge.labels(component='redis').set(1)
            
            self.logger.info("Redis initialized successfully")
            
        except Exception as e:
            self._health_status['redis'] = False
            container_health_gauge.labels(component='redis').set(0)
            self.logger.warning(f"Redis initialization failed: {e}")
            # Don't raise - Redis is optional
    
    def _register_service_factories(self) -> None:
        """Register service factory functions to avoid circular imports"""
        
        # Import service classes locally to avoid circular imports
        def register_ai_service():
            from src.application.services.ai_service import AIService
            self._service_factories[AIService] = self._create_ai_service
            
        def register_voice_service():
            from src.application.services.voice_interaction_service import VoiceInteractionService
            self._service_factories[VoiceInteractionService] = self._create_voice_service
            
        def register_streaming_service():
            from src.application.services.streaming_service import StreamingService
            self._service_factories[StreamingService] = self._create_streaming_service
            
        def register_moderation_service():
            from src.application.services.moderation_service import ModerationService
            self._service_factories[ModerationService] = self._create_moderation_service
            
        def register_memory_service():
            from src.application.services.memory_service import MemoryService
            self._service_factories[MemoryService] = self._create_memory_service
            
        def register_health_service():
            from src.application.services.health_service import HealthService
            self._service_factories[HealthService] = self._create_health_service
            
        # Register all factories
        register_ai_service()
        register_voice_service()
        register_streaming_service()
        register_moderation_service()
        register_memory_service()
        register_health_service()
        
        self.logger.info(f"Registered {len(self._service_factories)} service factories")
    
    async def _init_core_services(self) -> None:
        """Initialize core services that are always needed"""
        
        # Initialize repositories first
        await self._init_repositories()
        
        # Initialize audit logger
        from src.infrastructure.security.audit_logger import AuditLogger
        audit_logger = AuditLogger(self._session_factory)
        await self._registry.register("audit_logger", audit_logger)
        
        # Initialize session manager
        from src.infrastructure.session_manager import SessionManager
        session_manager = SessionManager(self._redis_client)
        await self._registry.register("session_manager", session_manager)
        
        self.logger.info("Core services initialized")
    
    async def _init_repositories(self) -> None:
        """Initialize repositories with lazy loading"""
        
        # Child repository
        from src.infrastructure.persistence.child_sqlite_repository import ChildSQLiteRepository
        child_repo = ChildSQLiteRepository(self._session_factory)
        await child_repo.initialize()
        self._repositories['child'] = child_repo
        await self._registry.register("child_repository", child_repo)
        
        # Conversation repository
        from src.infrastructure.persistence.conversation_sqlite_repository import ConversationSQLiteRepository
        conversation_repo = ConversationSQLiteRepository(self._session_factory)
        await conversation_repo.initialize()
        self._repositories['conversation'] = conversation_repo
        await self._registry.register("conversation_repository", conversation_repo)
        
        self.logger.info("Repositories initialized")
    
    async def get_service(self, service_class: Type[T]) -> T:
        """
        Get or create service instance with lazy loading
        Thread-safe service retrieval
        """
        if not self._initialized_flag:
            raise ContainerNotInitializedError("Container must be initialized before use")
            
        # Check cache first
        if service_class in self._services:
            return self._services[service_class]
            
        # Check if factory exists
        if service_class not in self._service_factories:
            raise ServiceNotFoundError(f"No factory registered for {service_class.__name__}")
            
        # Create service (thread-safe)
        async with self._init_lock:
            # Double-check after acquiring lock
            if service_class in self._services:
                return self._services[service_class]
                
            # Create new instance
            factory = self._service_factories[service_class]
            service = await factory()
            self._services[service_class] = service
            
            # Register in service registry
            await self._registry.register(service_class.__name__, service)
            
            return service
    
    # Service factory methods
    
    async def _create_ai_service(self):
        """Create AI service instance"""
        from src.application.services.ai_service import AIService
        
        service = AIService(self._registry, self.settings.to_dict())
        await service.initialize()
        return service
    
    async def _create_voice_service(self):
        """Create voice interaction service"""
        from src.application.services.voice_interaction_service import VoiceInteractionService
        
        service = VoiceInteractionService(self.settings.to_dict())
        # Set streaming service if available
        try:
            from src.application.services.streaming_service import StreamingService
            streaming = await self.get_service(StreamingService)
            service.set_streaming_service(streaming)
        except:
            pass
        return service
    
    async def _create_streaming_service(self):
        """Create streaming service"""
        from src.application.services.streaming_service import StreamingService
        
        return StreamingService(
            config=self.settings.to_dict(),
            conversation_repo=self._repositories['conversation']
        )
    
    async def _create_moderation_service(self):
        """Create moderation service"""
        from src.application.services.moderation_service import ModerationService
        
        return ModerationService(self.settings.to_dict())
    
    async def _create_memory_service(self):
        """Create memory service"""
        from src.application.services.memory_service import MemoryService
        
        service = MemoryService(
            config=self.settings.to_dict(),
            redis_client=self._redis_client
        )
        await service.initialize()
        return service
    
    async def _create_health_service(self):
        """Create health monitoring service"""
        from src.application.services.health_service import HealthService
        
        service = HealthService(self._registry, self.settings.to_dict())
        await service.initialize()
        return service
    
    # Repository access methods
    
    @property
    def child_repository(self):
        """Get child repository"""
        if not self._initialized_flag:
            raise ContainerNotInitializedError("Container not initialized")
        return self._repositories.get('child')
    
    @property
    def conversation_repository(self):
        """Get conversation repository"""
        if not self._initialized_flag:
            raise ContainerNotInitializedError("Container not initialized")
        return self._repositories.get('conversation')
    
    # Database session management
    
    @asynccontextmanager
    async def get_db_session(self):
        """Get database session with proper cleanup"""
        if not self._session_factory:
            raise ContainerNotInitializedError("Database not initialized")
            
        async with self._session_factory() as session:
            try:
                yield session
                await session.commit()
            except Exception:
                await session.rollback()
                raise
            finally:
                await session.close()
    
    # Health and cleanup
    
    async def health_check(self) -> Dict[str, Any]:
        """Comprehensive health check"""
        health = {
            'status': 'healthy' if all(self._health_status.values()) else 'unhealthy',
            'timestamp': datetime.utcnow().isoformat(),
            'components': {}
        }
        
        # Database health
        try:
            async with self.get_db_session() as session:
                await session.execute("SELECT 1")
            health['components']['database'] = {'status': 'healthy'}
        except Exception as e:
            health['components']['database'] = {
                'status': 'unhealthy',
                'error': str(e)
            }
        
        # Redis health
        if self._redis_client:
            try:
                await self._redis_client.ping()
                info = await self._redis_client.info()
                health['components']['redis'] = {
                    'status': 'healthy',
                    'connected_clients': info.get('connected_clients', 0)
                }
            except Exception as e:
                health['components']['redis'] = {
                    'status': 'unhealthy',
                    'error': str(e)
                }
        
        # Service registry health
        if self._registry:
            registry_health = await self._registry.health_check()
            health['components']['services'] = registry_health
        
        return health
    
    async def cleanup(self) -> None:
        """Cleanup all resources gracefully"""
        self.logger.info("Starting container cleanup")
        
        try:
            # Shutdown services
            if self._registry:
                await self._registry.shutdown()
            
            # Clear service cache
            self._services.clear()
            
            # Close Redis
            if self._redis_client:
                await self._redis_client.close()
                
            # Close database
            if self._engine:
                await self._engine.dispose()
                
            self._initialized_flag = False
            
            # Update metrics
            container_health_gauge.labels(component='database').set(0)
            container_health_gauge.labels(component='redis').set(0)
            
            self.logger.info("Container cleanup complete")
            
        except Exception as e:
            self.logger.error(f"Error during cleanup: {e}", exc_info=True)
    
    # Context manager support
    
    async def __aenter__(self):
        """Async context manager entry"""
        if not self._initialized_flag:
            await self.initialize()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.cleanup()


# Global container instance
_container: Optional[DependencyContainer] = None


async def get_container() -> DependencyContainer:
    """
    Get or create the global container instance
    Thread-safe singleton access
    """
    global _container
    
    if _container is None:
        _container = DependencyContainer()
        
    if not _container._initialized_flag:
        await _container.initialize()
        
    return _container


# Convenience function for FastAPI dependency injection
async def get_service(service_class: Type[T]) -> T:
    """
    FastAPI dependency for service injection
    
    Usage:
        @app.get("/")
        async def endpoint(ai_service: AIService = Depends(get_service(AIService))):
            ...
    """
    container = await get_container()
    return await container.get_service(service_class)


# Alias for backward compatibility
Container = DependencyContainer
