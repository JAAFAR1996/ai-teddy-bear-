"""
Redis-based Session Manager
Provides distributed, persistent session management
"""

import json
import time
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Set
from uuid import uuid4

import redis.asyncio as redis
from pydantic import BaseModel, Field
import structlog

logger = structlog.get_logger()


class SessionData(BaseModel):
    """Session data model"""
    session_id: str = Field(default_factory=lambda: str(uuid4()))
    user_id: Optional[str] = None
    child_id: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: Optional[datetime] = None
    data: Dict[str, Any] = Field(default_factory=dict)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    is_active: bool = True
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class RedisSessionManager:
    """
    Distributed session manager using Redis
    
    Features:
    - Automatic expiration
    - Session persistence
    - Concurrent access safety
    - Session analytics
    """
    
    def __init__(
        self,
        redis_url: str,
        ttl: int = 3600,  # 1 hour default
        key_prefix: str = "session:",
        max_sessions_per_user: int = 5
    ):
        self.redis_url = redis_url
        self.ttl = ttl
        self.key_prefix = key_prefix
        self.max_sessions_per_user = max_sessions_per_user
        self._client: Optional[redis.Redis] = None
        self._pubsub: Optional[redis.client.PubSub] = None
        self._listeners: Dict[str, List[callable]] = {}
    
    async def initialize(self) -> None:
        """Initialize Redis connection"""
        try:
            self._client = await redis.from_url(
                self.redis_url,
                encoding="utf-8",
                decode_responses=True,
                health_check_interval=30
            )
            
            # Test connection
            await self._client.ping()
            
            # Setup pub/sub
            self._pubsub = self._client.pubsub()
            
            logger.info("Redis session manager initialized")
            
        except Exception as e:
            logger.error("Failed to initialize Redis session manager", error=str(e))
            raise
    
    async def close(self) -> None:
        """Close Redis connections"""
        if self._pubsub:
            await self._pubsub.close()
        
        if self._client:
            await self._client.close()
    
    def _get_key(self, session_id: str) -> str:
        """Get Redis key for session"""
        return f"{self.key_prefix}{session_id}"
    
    def _get_user_sessions_key(self, user_id: str) -> str:
        """Get Redis key for user's sessions set"""
        return f"{self.key_prefix}user:{user_id}:sessions"
    
    async def create_session(
        self,
        user_id: Optional[str] = None,
        child_id: Optional[str] = None,
        data: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        ttl: Optional[int] = None
    ) -> SessionData:
        """Create a new session"""
        session = SessionData(
            user_id=user_id,
            child_id=child_id,
            data=data or {},
            metadata=metadata or {}
        )
        
        # Set expiration
        ttl = ttl or self.ttl
        if ttl > 0:
            session.expires_at = datetime.utcnow() + timedelta(seconds=ttl)
        
        # Check user session limit
        if user_id:
            await self._enforce_session_limit(user_id)
        
        # Store in Redis
        key = self._get_key(session.session_id)
        await self._client.setex(
            key,
            ttl,
            session.json()
        )
        
        # Add to user's sessions set
        if user_id:
            user_sessions_key = self._get_user_sessions_key(user_id)
            await self._client.sadd(user_sessions_key, session.session_id)
            await self._client.expire(user_sessions_key, ttl * 2)  # Longer TTL for the set
        
        # Publish session created event
        await self._publish_event("session_created", {
            "session_id": session.session_id,
            "user_id": user_id,
            "child_id": child_id
        })
        
        logger.info(
            "Session created",
            session_id=session.session_id,
            user_id=user_id,
            child_id=child_id
        )
        
        return session
    
    async def get_session(self, session_id: str) -> Optional[SessionData]:
        """Get session by ID"""
        key = self._get_key(session_id)
        data = await self._client.get(key)
        
        if not data:
            return None
        
        try:
            session = SessionData.parse_raw(data)
            
            # Check if expired
            if session.expires_at and session.expires_at < datetime.utcnow():
                await self.delete_session(session_id)
                return None
            
            return session
            
        except Exception as e:
            logger.error("Failed to parse session data", error=str(e))
            return None
    
    async def update_session(
        self,
        session_id: str,
        data: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        extend_ttl: bool = True
    ) -> Optional[SessionData]:
        """Update existing session"""
        session = await self.get_session(session_id)
        if not session:
            return None
        
        # Update data
        if data is not None:
            session.data.update(data)
        
        if metadata is not None:
            session.metadata.update(metadata)
        
        session.updated_at = datetime.utcnow()
        
        # Extend TTL if requested
        if extend_ttl and session.expires_at:
            ttl = self.ttl
            session.expires_at = datetime.utcnow() + timedelta(seconds=ttl)
        else:
            # Calculate remaining TTL
            ttl = int((session.expires_at - datetime.utcnow()).total_seconds()) if session.expires_at else 0
        
        # Update in Redis
        key = self._get_key(session_id)
        if ttl > 0:
            await self._client.setex(key, ttl, session.json())
        else:
            await self._client.set(key, session.json())
        
        # Publish session updated event
        await self._publish_event("session_updated", {
            "session_id": session_id,
            "user_id": session.user_id,
            "child_id": session.child_id
        })
        
        return session
    
    async def delete_session(self, session_id: str) -> bool:
        """Delete a session"""
        session = await self.get_session(session_id)
        if not session:
            return False
        
        # Remove from Redis
        key = self._get_key(session_id)
        await self._client.delete(key)
        
        # Remove from user's sessions set
        if session.user_id:
            user_sessions_key = self._get_user_sessions_key(session.user_id)
            await self._client.srem(user_sessions_key, session_id)
        
        # Publish session deleted event
        await self._publish_event("session_deleted", {
            "session_id": session_id,
            "user_id": session.user_id,
            "child_id": session.child_id
        })
        
        logger.info("Session deleted", session_id=session_id)
        
        return True
    
    async def get_user_sessions(self, user_id: str) -> List[SessionData]:
        """Get all sessions for a user"""
        user_sessions_key = self._get_user_sessions_key(user_id)
        session_ids = await self._client.smembers(user_sessions_key)
        
        sessions = []
        for session_id in session_ids:
            session = await self.get_session(session_id)
            if session:
                sessions.append(session)
            else:
                # Clean up stale reference
                await self._client.srem(user_sessions_key, session_id)
        
        return sessions
    
    async def get_active_sessions(self) -> List[SessionData]:
        """Get all active sessions"""
        pattern = f"{self.key_prefix}*"
        sessions = []
        
        # Use SCAN to avoid blocking on large datasets
        cursor = 0
        while True:
            cursor, keys = await self._client.scan(
                cursor,
                match=pattern,
                count=100
            )
            
            for key in keys:
                # Skip non-session keys
                if ":user:" in key:
                    continue
                
                session_id = key.replace(self.key_prefix, "")
                session = await self.get_session(session_id)
                if session and session.is_active:
                    sessions.append(session)
            
            if cursor == 0:
                break
        
        return sessions
    
    async def cleanup_expired_sessions(self) -> int:
        """Clean up expired sessions"""
        pattern = f"{self.key_prefix}*"
        cleaned = 0
        
        cursor = 0
        while True:
            cursor, keys = await self._client.scan(
                cursor,
                match=pattern,
                count=100
            )
            
            for key in keys:
                # Skip non-session keys
                if ":user:" in key:
                    continue
                
                # Check TTL
                ttl = await self._client.ttl(key)
                if ttl == -1:  # No expiration set
                    session_id = key.replace(self.key_prefix, "")
                    session = await self.get_session(session_id)
                    
                    if session and session.expires_at and session.expires_at < datetime.utcnow():
                        await self.delete_session(session_id)
                        cleaned += 1
            
            if cursor == 0:
                break
        
        logger.info("Cleaned up expired sessions", count=cleaned)
        return cleaned
    
    async def _enforce_session_limit(self, user_id: str) -> None:
        """Enforce maximum sessions per user"""
        sessions = await self.get_user_sessions(user_id)
        
        if len(sessions) >= self.max_sessions_per_user:
            # Sort by created_at and remove oldest
            sessions.sort(key=lambda s: s.created_at)
            
            # Delete oldest sessions
            for session in sessions[:len(sessions) - self.max_sessions_per_user + 1]:
                await self.delete_session(session.session_id)
                logger.info(
                    "Deleted old session due to limit",
                    session_id=session.session_id,
                    user_id=user_id
                )
    
    async def _publish_event(self, event_type: str, data: Dict[str, Any]) -> None:
        """Publish session event"""
        if not self._client:
            return
        
        channel = f"{self.key_prefix}events"
        message = {
            "type": event_type,
            "timestamp": datetime.utcnow().isoformat(),
            "data": data
        }
        
        await self._client.publish(channel, json.dumps(message))
    
    async def subscribe_to_events(self, callback: callable) -> None:
        """Subscribe to session events"""
        if not self._pubsub:
            return
        
        channel = f"{self.key_prefix}events"
        await self._pubsub.subscribe(channel)
        
        async def listener():
            async for message in self._pubsub.listen():
                if message["type"] == "message":
                    try:
                        data = json.loads(message["data"])
                        await callback(data)
                    except Exception as e:
                        logger.error("Event handler error", error=str(e))
        
        # Start listener task
        asyncio.create_task(listener())
    
    async def get_session_analytics(self) -> Dict[str, Any]:
        """Get session analytics"""
        sessions = await self.get_active_sessions()
        
        total_sessions = len(sessions)
        active_users = len(set(s.user_id for s in sessions if s.user_id))
        active_children = len(set(s.child_id for s in sessions if s.child_id))
        
        # Calculate average session age
        now = datetime.utcnow()
        session_ages = [(now - s.created_at).total_seconds() for s in sessions]
        avg_session_age = sum(session_ages) / len(session_ages) if session_ages else 0
        
        return {
            "total_sessions": total_sessions,
            "active_users": active_users,
            "active_children": active_children,
            "average_session_age_seconds": avg_session_age,
            "sessions_by_user": self._count_by_user(sessions),
            "sessions_by_child": self._count_by_child(sessions),
            "timestamp": datetime.utcnow().isoformat()
        }
    
    def _count_by_user(self, sessions: List[SessionData]) -> Dict[str, int]:
        """Count sessions by user"""
        counts = {}
        for session in sessions:
            if session.user_id:
                counts[session.user_id] = counts.get(session.user_id, 0) + 1
        return counts
    
    def _count_by_child(self, sessions: List[SessionData]) -> Dict[str, int]:
        """Count sessions by child"""
        counts = {}
        for session in sessions:
            if session.child_id:
                counts[session.child_id] = counts.get(session.child_id, 0) + 1
        return counts


# Convenience functions
async def get_session_manager(redis_url: str, **kwargs) -> RedisSessionManager:
    """Get initialized session manager"""
    manager = RedisSessionManager(redis_url, **kwargs)
    await manager.initialize()
    return manager 