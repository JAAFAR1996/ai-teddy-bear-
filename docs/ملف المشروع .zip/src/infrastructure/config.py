"""
Enterprise Configuration Management - 2025
Advanced configuration system with Pydantic Settings v2, validation, and security
"""

import os
import secrets
from functools import lru_cache
from pathlib import Path
from typing import Dict, List, Optional, Union, Any, Set
from urllib.parse import urlparse

from pydantic import (
    Field, field_validator, model_validator, 
    SecretStr, AnyHttpUrl, ValidationError
)
from pydantic_settings import BaseSettings, SettingsConfigDict
import structlog

logger = structlog.get_logger()


class DatabaseSettings(BaseSettings):
    """Database configuration settings"""
    
    # Database connection
    database_url: str = Field(
        default="sqlite+aiosqlite:///./data/teddy.db",
        description="Database connection URL"
    )
    database_pool_size: int = Field(default=10, ge=1, le=100)
    database_max_overflow: int = Field(default=20, ge=0, le=100)
    database_pool_timeout: int = Field(default=30, ge=1, le=300)
    database_pool_recycle: int = Field(default=3600, ge=300, le=86400)
    
    # Connection retry settings
    database_retry_attempts: int = Field(default=3, ge=1, le=10)
    database_retry_delay: float = Field(default=1.0, ge=0.1, le=60.0)
    
    # Database security
    database_ssl_mode: str = Field(default="prefer", pattern="^(disable|allow|prefer|require|verify-ca|verify-full)$")
    database_ssl_cert: Optional[Path] = None
    database_ssl_key: Optional[Path] = None
    database_ssl_ca: Optional[Path] = None
    
    @field_validator('database_url')
    @classmethod
    def validate_database_url(cls, v):
        """Validate database URL format"""
        try:
            parsed = urlparse(v)
            if not parsed.scheme:
                raise ValueError("Database URL must include a scheme")
            return v
        except Exception as e:
            raise ValueError(f"Invalid database URL: {e}")
    
    model_config = SettingsConfigDict(
        env_prefix="DATABASE_",
        case_sensitive=False
    )


class RedisSettings(BaseSettings):
    """Redis configuration settings"""
    
    redis_url: str = Field(
        default="redis://localhost:6379/0",
        description="Redis connection URL"
    )
    redis_password: Optional[SecretStr] = None
    redis_ssl: bool = Field(default=False)
    redis_ssl_cert_reqs: str = Field(default="required")
    
    # Connection pool settings
    redis_max_connections: int = Field(default=20, ge=1, le=1000)
    redis_socket_timeout: float = Field(default=5.0, ge=0.1, le=60.0)
    redis_socket_connect_timeout: float = Field(default=5.0, ge=0.1, le=60.0)
    redis_retry_on_timeout: bool = True
    
    # Cluster settings
    redis_cluster_enabled: bool = False
    redis_cluster_nodes: List[str] = Field(default_factory=list)
    
    @field_validator('redis_url')
    @classmethod
    def validate_redis_url(cls, v):
        """Validate Redis URL format"""
        try:
            parsed = urlparse(v)
            if parsed.scheme not in ['redis', 'rediss', 'unix']:
                raise ValueError("Redis URL must use redis, rediss, or unix scheme")
            return v
        except Exception as e:
            raise ValueError(f"Invalid Redis URL: {e}")
    
    model_config = SettingsConfigDict(
        env_prefix="REDIS_",
        case_sensitive=False
    )


class SecuritySettings(BaseSettings):
    """Security configuration settings"""
    
    # Encryption
    secret_key: SecretStr = Field(
        default_factory=lambda: SecretStr(secrets.token_urlsafe(32)),
        description="Secret key for encryption and signing"
    )
    encryption_key: SecretStr = Field(
        default_factory=lambda: SecretStr(secrets.token_urlsafe(32)),
        description="Key for data encryption"
    )
    
    # JWT settings
    jwt_secret: SecretStr = Field(
        default_factory=lambda: SecretStr(secrets.token_urlsafe(32)),
        description="JWT signing secret"
    )
    jwt_algorithm: str = Field(default="HS256")
    jwt_expire_minutes: int = Field(default=30, ge=1, le=10080)  # Max 1 week
    jwt_refresh_expire_days: int = Field(default=7, ge=1, le=90)
    
    # Password security
    password_min_length: int = Field(default=12, ge=8, le=128)
    password_require_uppercase: bool = True
    password_require_lowercase: bool = True
    password_require_digits: bool = True
    password_require_symbols: bool = True
    password_history_size: int = Field(default=12, ge=0, le=50)
    password_max_age_days: int = Field(default=90, ge=0, le=365)
    
    # Rate limiting
    rate_limit_enabled: bool = True
    rate_limit_per_minute: int = Field(default=100, ge=1, le=10000)
    rate_limit_burst: int = Field(default=200, ge=1, le=20000)
    
    # CORS settings
    cors_origins: List[str] = Field(
        default=["http://localhost:3000", "http://localhost:8080"],
        description="Allowed CORS origins"
    )
    cors_credentials: bool = True
    cors_methods: List[str] = Field(default=["GET", "POST", "PUT", "DELETE", "OPTIONS"])
    cors_headers: List[str] = Field(default=["*"])
    
    # Security headers
    security_headers_enabled: bool = True
    hsts_max_age: int = Field(default=31536000, ge=0)  # 1 year
    content_security_policy: str = Field(
        default="default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'"
    )
    
    # IP filtering
    allowed_ips: Set[str] = Field(default_factory=set)
    blocked_ips: Set[str] = Field(default_factory=set)
    
    @field_validator('cors_origins')
    @classmethod
    def validate_cors_origins(cls, v):
        """Validate CORS origins"""
        for origin in v:
            if origin != "*":
                try:
                    parsed = urlparse(origin)
                    if not parsed.scheme or not parsed.netloc:
                        raise ValueError(f"Invalid CORS origin: {origin}")
                except Exception:
                    raise ValueError(f"Invalid CORS origin format: {origin}")
        return v
    
    model_config = SettingsConfigDict(
        env_prefix="SECURITY_",
        case_sensitive=False
    )


class AISettings(BaseSettings):
    """AI and ML configuration settings"""
    
    # OpenAI settings
    openai_api_key: Optional[SecretStr] = None
    openai_model: str = Field(default="gpt-4-turbo-preview")
    openai_max_tokens: int = Field(default=1000, ge=1, le=8192)
    openai_temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    openai_timeout: float = Field(default=30.0, ge=1.0, le=300.0)
    
    # Azure OpenAI settings
    azure_openai_endpoint: Optional[AnyHttpUrl] = None
    azure_openai_api_key: Optional[SecretStr] = None
    azure_openai_api_version: str = Field(default="2024-02-01")
    azure_openai_deployment_name: Optional[str] = None
    
    # Anthropic settings
    anthropic_api_key: Optional[SecretStr] = None
    anthropic_model: str = Field(default="claude-3-sonnet-20240229")
    anthropic_max_tokens: int = Field(default=1000, ge=1, le=4096)
    
    # Speech settings
    speech_service: str = Field(default="azure", pattern="^(azure|openai|whisper)$")
    azure_speech_key: Optional[SecretStr] = None
    azure_speech_region: Optional[str] = None
    
    # Audio processing
    audio_sample_rate: int = Field(default=16000, ge=8000, le=48000)
    audio_channels: int = Field(default=1, ge=1, le=2)
    audio_max_duration: int = Field(default=60, ge=1, le=300)  # seconds
    audio_format: str = Field(default="wav", pattern="^(wav|mp3|flac|ogg)$")
    
    # Content moderation
    content_moderation_enabled: bool = True
    content_moderation_strict_mode: bool = False
    content_moderation_custom_filters: List[str] = Field(default_factory=list)
    
    model_config = SettingsConfigDict(
        env_prefix="AI_",
        case_sensitive=False
    )


class MonitoringSettings(BaseSettings):
    """Monitoring and observability settings"""
    
    # Logging
    log_level: str = Field(default="INFO", pattern="^(DEBUG|INFO|WARNING|ERROR|CRITICAL)$")
    log_format: str = Field(default="json", pattern="^(json|text)$")
    log_file: Optional[Path] = None
    log_max_size: int = Field(default=10485760, ge=1024)  # 10MB
    log_backup_count: int = Field(default=5, ge=0, le=50)
    
    # Structured logging
    structured_logging: bool = True
    log_correlation_id: bool = True
    log_request_id: bool = True
    
    # Metrics
    metrics_enabled: bool = True
    prometheus_enabled: bool = True
    prometheus_port: int = Field(default=9090, ge=1, le=65535)
    
    # Tracing
    tracing_enabled: bool = False
    jaeger_endpoint: Optional[AnyHttpUrl] = None
    jaeger_service_name: str = Field(default="ai-teddy-bear")
    otlp_endpoint: Optional[AnyHttpUrl] = None
    
    # Health checks
    health_checks_enabled: bool = True
    health_check_interval: int = Field(default=30, ge=1, le=3600)
    health_check_timeout: int = Field(default=10, ge=1, le=60)
    
    # Error tracking
    sentry_enabled: bool = False
    sentry_dsn: Optional[SecretStr] = None
    sentry_environment: Optional[str] = None
    sentry_traces_sample_rate: float = Field(default=0.1, ge=0.0, le=1.0)
    
    model_config = SettingsConfigDict(
        env_prefix="MONITORING_",
        case_sensitive=False
    )


class PerformanceSettings(BaseSettings):
    """Performance and optimization settings"""
    
    # Server settings
    workers: int = Field(default=1, ge=1, le=64)
    worker_connections: int = Field(default=1000, ge=100, le=10000)
    keepalive_timeout: int = Field(default=2, ge=1, le=300)
    client_timeout: int = Field(default=60, ge=1, le=3600)
    
    # Caching
    cache_enabled: bool = True
    cache_ttl: int = Field(default=300, ge=1, le=86400)  # 5 minutes default
    cache_max_size: int = Field(default=1000, ge=1, le=100000)
    
    # Connection pools
    http_pool_connections: int = Field(default=20, ge=1, le=100)
    http_pool_maxsize: int = Field(default=20, ge=1, le=100)
    http_max_retries: int = Field(default=3, ge=0, le=10)
    
    # File upload limits
    max_upload_size: int = Field(default=10485760, ge=1024)  # 10MB
    max_audio_duration: int = Field(default=300, ge=1, le=3600)  # 5 minutes
    
    # WebSocket settings
    websocket_ping_interval: int = Field(default=20, ge=1, le=300)
    websocket_ping_timeout: int = Field(default=20, ge=1, le=300)
    websocket_max_connections: int = Field(default=1000, ge=1, le=10000)
    
    model_config = SettingsConfigDict(
        env_prefix="PERFORMANCE_",
        case_sensitive=False
    )


class Settings(BaseSettings):
    """Main application settings combining all configuration sections"""
    
    # Basic application settings
    app_name: str = Field(default="AI Teddy Bear")
    app_version: str = Field(default="2.0.0")
    environment: str = Field(default="development", pattern="^(development|staging|production)$")
    debug: bool = Field(default=False)
    
    # Server configuration
    host: str = Field(default="0.0.0.0")
    port: int = Field(default=8000, ge=1, le=65535)
    
    # Trusted hosts
    allowed_hosts: List[str] = Field(default=["*"])
    
    # Feature flags
    feature_flags: Dict[str, bool] = Field(default_factory=dict)
    
    # Component settings
    database: DatabaseSettings = Field(default_factory=DatabaseSettings)
    redis: RedisSettings = Field(default_factory=RedisSettings)
    security: SecuritySettings = Field(default_factory=SecuritySettings)
    ai: AISettings = Field(default_factory=AISettings)
    monitoring: MonitoringSettings = Field(default_factory=MonitoringSettings)
    performance: PerformanceSettings = Field(default_factory=PerformanceSettings)
    
    @model_validator(mode='before')
    @classmethod
    def validate_configuration(cls, values):
        """Cross-field validation"""
        environment = values.get('environment', 'development')
        
        # Production environment validations
        if environment == 'production':
            # Ensure debug is disabled in production
            if values.get('debug', False):
                logger.warning("Debug mode disabled in production")
                values['debug'] = False
            
            # Ensure security settings are appropriate for production
            security = values.get('security')
            if security:
                if not security.rate_limit_enabled:
                    logger.warning("Rate limiting should be enabled in production")
                
                if '*' in security.cors_origins:
                    logger.warning("Wildcard CORS origins should not be used in production")
        
        return values
    
    @field_validator('allowed_hosts')
    @classmethod
    def validate_allowed_hosts(cls, v, info):
        """Validate allowed hosts"""
        if info.data:
            environment = info.data.get('environment', 'development')
        else:
            environment = 'development'
        
        if environment == 'production' and '*' in v:
            logger.warning("Wildcard in allowed_hosts should not be used in production")
        
        return v
    
    @property
    def is_development(self) -> bool:
        """Check if running in development mode"""
        return self.environment == 'development'
    
    @property
    def is_production(self) -> bool:
        """Check if running in production mode"""
        return self.environment == 'production'
    
    @property
    def is_testing(self) -> bool:
        """Check if running in testing mode"""
        return self.environment == 'testing'
    
    def get_database_url(self, async_driver: bool = True) -> str:
        """Get database URL with appropriate driver"""
        url = self.database.database_url
        
        if async_driver and 'sqlite' in url and 'aiosqlite' not in url:
            return url.replace('sqlite://', 'sqlite+aiosqlite://')
        elif not async_driver and 'aiosqlite' in url:
            return url.replace('sqlite+aiosqlite://', 'sqlite://')
        
        return url
    
    def get_redis_url(self) -> str:
        """Get Redis URL with credentials if configured"""
        url = self.redis.redis_url
        
        if self.redis.redis_password:
            parsed = urlparse(url)
            password = self.redis.redis_password.get_secret_value()
            
            # Insert password into URL
            if parsed.username:
                netloc = f"{parsed.username}:{password}@{parsed.hostname}"
            else:
                netloc = f":{password}@{parsed.hostname}"
            
            if parsed.port:
                netloc += f":{parsed.port}"
            
            url = f"{parsed.scheme}://{netloc}{parsed.path}"
            
            if parsed.query:
                url += f"?{parsed.query}"
        
        return url
    
    def export_env_vars(self) -> Dict[str, str]:
        """Export configuration as environment variables"""
        env_vars = {}
        
        # Basic settings
        env_vars.update({
            'APP_NAME': self.app_name,
            'APP_VERSION': self.app_version,
            'ENVIRONMENT': self.environment,
            'DEBUG': str(self.debug).lower(),
            'HOST': self.host,
            'PORT': str(self.port),
        })
        
        # Add component-specific env vars
        for component_name, component in [
            ('database', self.database),
            ('redis', self.redis),
            ('security', self.security),
            ('ai', self.ai),
            ('monitoring', self.monitoring),
            ('performance', self.performance),
        ]:
            component_dict = component.dict()
            for key, value in component_dict.items():
                if value is not None:
                    env_key = f"{component_name.upper()}_{key.upper()}"
                    if isinstance(value, SecretStr):
                        env_vars[env_key] = value.get_secret_value()
                    elif isinstance(value, (list, dict)):
                        env_vars[env_key] = str(value)
                    else:
                        env_vars[env_key] = str(value)
        
        return env_vars
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        validate_assignment=True,
        extra="ignore"
    )


# Global settings cache
@lru_cache()
def get_settings() -> Settings:
    """Get cached application settings"""
    try:
        settings = Settings()
        
        # Log configuration summary (without secrets)
        logger.info(
            "Configuration loaded",
            app_name=settings.app_name,
            version=settings.app_version,
            environment=settings.environment,
            debug=settings.debug,
            host=settings.host,
            port=settings.port
        )
        
        return settings
        
    except ValidationError as e:
        logger.error("Configuration validation failed", errors=e.errors())
        raise
    except Exception as e:
        logger.error("Failed to load configuration", error=str(e))
        raise


def validate_configuration(settings: Settings) -> List[str]:
    """Validate configuration and return list of warnings/errors"""
    warnings = []
    
    # Check for required API keys in production
    if settings.is_production:
        if not settings.ai.openai_api_key and not settings.ai.azure_openai_api_key:
            warnings.append("No AI API key configured for production")
        
        if not settings.ai.azure_speech_key:
            warnings.append("No speech service API key configured")
        
        if settings.debug:
            warnings.append("Debug mode should be disabled in production")
    
    # Check database configuration
    if 'sqlite' in settings.database.database_url and settings.is_production:
        warnings.append("SQLite should not be used in production")
    
    # Check security configuration
    if not settings.security.rate_limit_enabled:
        warnings.append("Rate limiting is disabled")
    
    return warnings


def load_configuration_from_file(file_path: Union[str, Path]) -> Settings:
    """Load configuration from a specific file"""
    file_path = Path(file_path)
    
    if not file_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {file_path}")
    
    # Set environment variable to point to the file
    os.environ['ENV_FILE'] = str(file_path)
    
    # Clear cache and reload
    get_settings.cache_clear()
    return get_settings()


# Export commonly used settings for convenience
def get_database_settings() -> DatabaseSettings:
    """Get database settings"""
    return get_settings().database


def get_security_settings() -> SecuritySettings:
    """Get security settings"""
    return get_settings().security


def get_ai_settings() -> AISettings:
    """Get AI settings"""
    return get_settings().ai


def get_monitoring_settings() -> MonitoringSettings:
    """Get monitoring settings"""
    return get_settings().monitoring


# Backward compatibility alias
@lru_cache()
def get_config() -> Settings:
    """Alias for get_settings() for backward compatibility"""
    return get_settings()
