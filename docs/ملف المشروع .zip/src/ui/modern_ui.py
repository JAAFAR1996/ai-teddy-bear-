"""
Modern PySide6 UI for AI Teddy Bear - Enterprise Grade 2025
Replaces deprecated tkinter with modern, responsive interface
"""

import asyncio
import json
import logging
import sys
from datetime import datetime
from typing import Dict, Optional, Any, List
from pathlib import Path

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTabWidget, QPushButton, QLabel, QTextEdit, QLineEdit, QComboBox,
    QProgressBar, QSplitter, QGroupBox, QGridLayout, QListWidget,
    QStatusBar, QMenuBar, QAction, QDialog, QMessageBox, QSystemTrayIcon,
    QStyle, QTableWidget, QTableWidgetItem, QHeaderView, QSpacerItem,
    QSizePolicy, QFrame, QScrollArea, QSlider, QCheckBox, QSpinBox
)
from PySide6.QtCore import (
    Qt, QTimer, QThread, Signal, QObject, QPropertyAnimation, QEasingCurve,
    QRect, QUrl, QSettings, QSize, QPoint, QDateTime, QRunnable, QThreadPool
)
from PySide6.QtGui import (
    QFont, QPixmap, QIcon, QPalette, QColor, QLinearGradient, QGradient,
    QPainter, QBrush, QPen, QAction as QGuiAction, QDesktopServices,
    QMovie, QTextCursor, QSyntaxHighlighter, QTextCharFormat
)
from PySide6.QtCharts import QChart, QChartView, QLineSeries, QDateTimeAxis, QValueAxis
from PySide6.QtWebSockets import QWebSocket
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkReply

import structlog

logger = structlog.get_logger()


class WebSocketClient(QObject):
    """Enterprise WebSocket client with auto-reconnection"""
    
    connected = Signal()
    disconnected = Signal()
    message_received = Signal(dict)
    error_occurred = Signal(str)
    connection_status_changed = Signal(str)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.websocket = QWebSocket()
        self.url = QUrl("ws://localhost:8000/ws/ui_session")
        self.reconnect_timer = QTimer()
        self.heartbeat_timer = QTimer()
        self.is_connected = False
        self.reconnect_attempts = 0
        self.max_reconnect_attempts = 10
        
        # Setup timers
        self.reconnect_timer.timeout.connect(self._attempt_reconnect)
        self.heartbeat_timer.timeout.connect(self._send_heartbeat)
        self.heartbeat_timer.start(30000)  # 30 seconds
        
        # Setup WebSocket signals
        self.websocket.connected.connect(self._on_connected)
        self.websocket.disconnected.connect(self._on_disconnected)
        self.websocket.textMessageReceived.connect(self._on_message_received)
        self.websocket.errorOccurred.connect(self._on_error)
    
    def connect_to_server(self):
        """Connect to WebSocket server"""
        logger.info("Attempting WebSocket connection", url=str(self.url))
        self.connection_status_changed.emit("Connecting...")
        self.websocket.open(self.url)
    
    def disconnect_from_server(self):
        """Disconnect from WebSocket server"""
        self.websocket.close()
        self.reconnect_timer.stop()
    
    def send_message(self, message: Dict[str, Any]):
        """Send message to server"""
        if self.is_connected:
            json_message = json.dumps(message)
            self.websocket.sendTextMessage(json_message)
            logger.debug("Sent WebSocket message", message_type=message.get("type"))
    
    def _on_connected(self):
        """Handle successful connection"""
        self.is_connected = True
        self.reconnect_attempts = 0
        self.reconnect_timer.stop()
        self.connection_status_changed.emit("Connected")
        self.connected.emit()
        logger.info("WebSocket connected successfully")
    
    def _on_disconnected(self):
        """Handle disconnection"""
        self.is_connected = False
        self.connection_status_changed.emit("Disconnected")
        self.disconnected.emit()
        logger.warning("WebSocket disconnected")
        
        if self.reconnect_attempts < self.max_reconnect_attempts:
            self.reconnect_timer.start(5000)  # Retry in 5 seconds
    
    def _on_message_received(self, message: str):
        """Handle received message"""
        try:
            data = json.loads(message)
            self.message_received.emit(data)
            logger.debug("Received WebSocket message", message_type=data.get("type"))
        except json.JSONDecodeError as e:
            logger.error("Failed to parse WebSocket message", error=str(e))
            self.error_occurred.emit(f"Invalid message format: {e}")
    
    def _on_error(self, error):
        """Handle WebSocket error"""
        error_msg = f"WebSocket error: {error}"
        logger.error(error_msg)
        self.error_occurred.emit(error_msg)
        self.connection_status_changed.emit("Error")
    
    def _attempt_reconnect(self):
        """Attempt to reconnect"""
        self.reconnect_attempts += 1
        if self.reconnect_attempts <= self.max_reconnect_attempts:
            logger.info("Attempting reconnection", attempt=self.reconnect_attempts)
            self.connect_to_server()
        else:
            self.reconnect_timer.stop()
            self.connection_status_changed.emit("Failed")
            logger.error("Max reconnection attempts reached")
    
    def _send_heartbeat(self):
        """Send heartbeat to keep connection alive"""
        if self.is_connected:
            self.send_message({"type": "ping", "timestamp": datetime.now().isoformat()})


class ModernDashboardWidget(QWidget):
    """Modern dashboard with real-time metrics"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        self.setup_timers()
        
    def setup_ui(self):
        """Setup dashboard UI"""
        layout = QVBoxLayout(self)
        
        # Metrics grid
        metrics_group = QGroupBox("System Metrics")
        metrics_layout = QGridLayout(metrics_group)
        
        # Connection status
        self.connection_label = QLabel("Connection: Disconnected")
        self.connection_label.setStyleSheet("QLabel { color: red; font-weight: bold; }")
        metrics_layout.addWidget(QLabel("Status:"), 0, 0)
        metrics_layout.addWidget(self.connection_label, 0, 1)
        
        # Active sessions
        self.sessions_label = QLabel("0")
        metrics_layout.addWidget(QLabel("Active Sessions:"), 1, 0)
        metrics_layout.addWidget(self.sessions_label, 1, 1)
        
        # Messages processed
        self.messages_label = QLabel("0")
        metrics_layout.addWidget(QLabel("Messages Processed:"), 2, 0)
        metrics_layout.addWidget(self.messages_label, 2, 1)
        
        # System health
        self.health_progress = QProgressBar()
        self.health_progress.setRange(0, 100)
        self.health_progress.setValue(100)
        metrics_layout.addWidget(QLabel("System Health:"), 3, 0)
        metrics_layout.addWidget(self.health_progress, 3, 1)
        
        layout.addWidget(metrics_group)
        
        # Performance chart
        self.chart_view = self.create_performance_chart()
        layout.addWidget(self.chart_view)
    
    def create_performance_chart(self) -> QChartView:
        """Create performance monitoring chart"""
        chart = QChart()
        chart.setTitle("Response Time (ms)")
        chart.setAnimationOptions(QChart.SeriesAnimations)
        
        series = QLineSeries()
        series.setName("Response Time")
        
        # Add some sample data
        for i in range(10):
            series.append(i, 50 + (i * 10))
        
        chart.addSeries(series)
        chart.createDefaultAxes()
        
        chart_view = QChartView(chart)
        chart_view.setRenderHint(QPainter.Antialiasing)
        
        return chart_view
    
    def setup_timers(self):
        """Setup update timers"""
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update_metrics)
        self.update_timer.start(5000)  # Update every 5 seconds
    
    def update_metrics(self):
        """Update dashboard metrics"""
        # This would be connected to real metrics from the backend
        import random
        
        # Simulate metrics updates
        sessions = random.randint(0, 50)
        messages = random.randint(0, 1000)
        health = random.randint(80, 100)
        
        self.sessions_label.setText(str(sessions))
        self.messages_label.setText(str(messages))
        self.health_progress.setValue(health)
    
    def update_connection_status(self, status: str):
        """Update connection status"""
        color_map = {
            "Connected": "green",
            "Connecting...": "orange",
            "Disconnected": "red",
            "Error": "red",
            "Failed": "red"
        }
        
        color = color_map.get(status, "gray")
        self.connection_label.setText(f"Connection: {status}")
        self.connection_label.setStyleSheet(f"QLabel {{ color: {color}; font-weight: bold; }}")


class ModernAudioWidget(QWidget):
    """Modern audio interface widget"""
    
    audio_recorded = Signal(bytes)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        self.is_recording = False
        
    def setup_ui(self):
        """Setup audio interface"""
        layout = QVBoxLayout(self)
        
        # Recording controls
        controls_group = QGroupBox("Audio Controls")
        controls_layout = QHBoxLayout(controls_group)
        
        self.record_button = QPushButton("🎤 Start Recording")
        self.record_button.setMinimumHeight(60)
        self.record_button.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                border-radius: 8px;
                font-size: 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QPushButton:pressed {
                background-color: #0D47A1;
            }
        """)
        self.record_button.clicked.connect(self.toggle_recording)
        
        self.stop_button = QPushButton("⏹️ Stop")
        self.stop_button.setMinimumHeight(60)
        self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self.stop_recording)
        
        controls_layout.addWidget(self.record_button)
        controls_layout.addWidget(self.stop_button)
        
        layout.addWidget(controls_group)
        
        # Audio visualization
        viz_group = QGroupBox("Audio Visualization")
        viz_layout = QVBoxLayout(viz_group)
        
        self.volume_meter = QProgressBar()
        self.volume_meter.setRange(0, 100)
        self.volume_meter.setStyleSheet("""
            QProgressBar {
                border: 2px solid #ddd;
                border-radius: 5px;
                text-align: center;
            }
            QProgressBar::chunk {
                background-color: #4CAF50;
                border-radius: 3px;
            }
        """)
        
        viz_layout.addWidget(QLabel("Volume Level:"))
        viz_layout.addWidget(self.volume_meter)
        
        layout.addWidget(viz_group)
        
        # Recording status
        self.status_label = QLabel("Ready to record")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet("QLabel { font-size: 14px; color: #666; }")
        layout.addWidget(self.status_label)
    
    def toggle_recording(self):
        """Toggle recording state"""
        if not self.is_recording:
            self.start_recording()
        else:
            self.stop_recording()
    
    def start_recording(self):
        """Start recording audio"""
        self.is_recording = True
        self.record_button.setText("🔴 Recording...")
        self.record_button.setStyleSheet("""
            QPushButton {
                background-color: #f44336;
                color: white;
                border: none;
                border-radius: 8px;
                font-size: 16px;
                font-weight: bold;
            }
        """)
        self.stop_button.setEnabled(True)
        self.status_label.setText("Recording in progress...")
        
        # TODO: Implement actual audio recording
        logger.info("Audio recording started")
    
    def stop_recording(self):
        """Stop recording audio"""
        self.is_recording = False
        self.record_button.setText("🎤 Start Recording")
        self.record_button.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                border-radius: 8px;
                font-size: 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        self.stop_button.setEnabled(False)
        self.status_label.setText("Processing audio...")
        
        # TODO: Implement actual audio processing
        logger.info("Audio recording stopped")
        
        # Simulate audio processing
        QTimer.singleShot(2000, lambda: self.status_label.setText("Ready to record"))


class ConversationWidget(QWidget):
    """Modern conversation display widget"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        self.conversation_history = []
        
    def setup_ui(self):
        """Setup conversation UI"""
        layout = QVBoxLayout(self)
        
        # Conversation display
        self.conversation_text = QTextEdit()
        self.conversation_text.setReadOnly(True)
        self.conversation_text.setStyleSheet("""
            QTextEdit {
                background-color: #f8f9fa;
                border: 1px solid #e0e0e0;
                border-radius: 8px;
                padding: 12px;
                font-family: 'Segoe UI', sans-serif;
                font-size: 14px;
                line-height: 1.4;
            }
        """)
        
        layout.addWidget(QLabel("Conversation History:"))
        layout.addWidget(self.conversation_text)
        
        # Input area
        input_group = QGroupBox("Send Message")
        input_layout = QHBoxLayout(input_group)
        
        self.message_input = QLineEdit()
        self.message_input.setPlaceholderText("Type your message here...")
        self.message_input.setMinimumHeight(40)
        self.message_input.returnPressed.connect(self.send_message)
        
        self.send_button = QPushButton("Send")
        self.send_button.setMinimumHeight(40)
        self.send_button.setMinimumWidth(80)
        self.send_button.clicked.connect(self.send_message)
        
        input_layout.addWidget(self.message_input)
        input_layout.addWidget(self.send_button)
        
        layout.addWidget(input_group)
    
    def add_message(self, sender: str, message: str, timestamp: Optional[datetime] = None):
        """Add message to conversation"""
        if timestamp is None:
            timestamp = datetime.now()
        
        time_str = timestamp.strftime("%H:%M:%S")
        
        # Add to history
        self.conversation_history.append({
            "sender": sender,
            "message": message,
            "timestamp": timestamp
        })
        
        # Format message
        if sender == "User":
            formatted = f'<div style="margin: 8px 0; padding: 8px; background-color: #e3f2fd; border-radius: 8px; text-align: right;"><strong>{sender}</strong> <span style="color: #666;">({time_str})</span><br>{message}</div>'
        else:
            formatted = f'<div style="margin: 8px 0; padding: 8px; background-color: #f1f8e9; border-radius: 8px;"><strong>{sender}</strong> <span style="color: #666;">({time_str})</span><br>{message}</div>'
        
        # Add to display
        self.conversation_text.append(formatted)
        
        # Scroll to bottom
        cursor = self.conversation_text.textCursor()
        cursor.movePosition(QTextCursor.End)
        self.conversation_text.setTextCursor(cursor)
    
    def send_message(self):
        """Send user message"""
        message = self.message_input.text().strip()
        if message:
            self.add_message("User", message)
            self.message_input.clear()
            
            # TODO: Send message to backend
            logger.info("User message sent", message=message)
            
            # Simulate AI response
            QTimer.singleShot(1500, lambda: self.add_message("AI Teddy", "Thank you for your message! I'm processing it..."))


class TeddyMainWindow(QMainWindow):
    """Main window for AI Teddy Bear application"""
    
    def __init__(self):
        super().__init__()
        self.websocket_client = WebSocketClient(self)
        self.settings = QSettings("AI Teddy", "TeddyBear")
        self.setup_ui()
        self.setup_connections()
        self.setup_system_tray()
        self.restore_window_state()
        
        # Connect to server on startup
        QTimer.singleShot(1000, self.websocket_client.connect_to_server)
    
    def setup_ui(self):
        """Setup main UI"""
        self.setWindowTitle("AI Teddy Bear - Enterprise Control Panel")
        self.setMinimumSize(1200, 800)
        
        # Apply modern styling
        self.setStyleSheet("""
            QMainWindow {
                background-color: #fafafa;
            }
            QTabWidget::pane {
                border: 1px solid #e0e0e0;
                background-color: white;
                border-radius: 8px;
            }
            QTabBar::tab {
                background-color: #f5f5f5;
                border: 1px solid #e0e0e0;
                padding: 8px 16px;
                margin-right: 2px;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
            }
            QTabBar::tab:selected {
                background-color: white;
                border-bottom: 1px solid white;
            }
            QGroupBox {
                font-weight: bold;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                margin-top: 8px;
                padding-top: 8px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 8px 0 8px;
            }
        """)
        
        # Central widget with tabs
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        layout = QVBoxLayout(central_widget)
        
        # Tab widget
        self.tab_widget = QTabWidget()
        
        # Dashboard tab
        self.dashboard_widget = ModernDashboardWidget()
        self.tab_widget.addTab(self.dashboard_widget, "📊 Dashboard")
        
        # Audio tab
        self.audio_widget = ModernAudioWidget()
        self.tab_widget.addTab(self.audio_widget, "🎤 Audio")
        
        # Conversation tab
        self.conversation_widget = ConversationWidget()
        self.tab_widget.addTab(self.conversation_widget, "💬 Conversation")
        
        # Settings tab
        self.settings_widget = self.create_settings_widget()
        self.tab_widget.addTab(self.settings_widget, "⚙️ Settings")
        
        layout.addWidget(self.tab_widget)
        
        # Setup menu bar
        self.create_menu_bar()
        
        # Setup status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        
        self.connection_status_label = QLabel("Disconnected")
        self.status_bar.addPermanentWidget(self.connection_status_label)
    
    def create_settings_widget(self) -> QWidget:
        """Create settings widget"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # Server settings
        server_group = QGroupBox("Server Configuration")
        server_layout = QGridLayout(server_group)
        
        server_layout.addWidget(QLabel("Server URL:"), 0, 0)
        self.server_url_input = QLineEdit("ws://localhost:8000")
        server_layout.addWidget(self.server_url_input, 0, 1)
        
        server_layout.addWidget(QLabel("API Key:"), 1, 0)
        self.api_key_input = QLineEdit()
        self.api_key_input.setEchoMode(QLineEdit.Password)
        server_layout.addWidget(self.api_key_input, 1, 1)
        
        layout.addWidget(server_group)
        
        # Audio settings
        audio_group = QGroupBox("Audio Configuration")
        audio_layout = QGridLayout(audio_group)
        
        audio_layout.addWidget(QLabel("Sample Rate:"), 0, 0)
        self.sample_rate_combo = QComboBox()
        self.sample_rate_combo.addItems(["16000", "22050", "44100", "48000"])
        audio_layout.addWidget(self.sample_rate_combo, 0, 1)
        
        audio_layout.addWidget(QLabel("Channels:"), 1, 0)
        self.channels_combo = QComboBox()
        self.channels_combo.addItems(["1 (Mono)", "2 (Stereo)"])
        audio_layout.addWidget(self.channels_combo, 1, 1)
        
        layout.addWidget(audio_group)
        
        # UI settings
        ui_group = QGroupBox("UI Preferences")
        ui_layout = QGridLayout(ui_group)
        
        self.dark_mode_checkbox = QCheckBox("Dark Mode")
        ui_layout.addWidget(self.dark_mode_checkbox, 0, 0)
        
        self.auto_connect_checkbox = QCheckBox("Auto-connect on startup")
        ui_layout.addWidget(self.auto_connect_checkbox, 1, 0)
        
        self.minimize_to_tray_checkbox = QCheckBox("Minimize to system tray")
        ui_layout.addWidget(self.minimize_to_tray_checkbox, 2, 0)
        
        layout.addWidget(ui_group)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        save_button = QPushButton("Save Settings")
        save_button.clicked.connect(self.save_settings)
        
        reset_button = QPushButton("Reset to Defaults")
        reset_button.clicked.connect(self.reset_settings)
        
        button_layout.addWidget(save_button)
        button_layout.addWidget(reset_button)
        button_layout.addStretch()
        
        layout.addLayout(button_layout)
        layout.addStretch()
        
        return widget
    
    def create_menu_bar(self):
        """Create application menu bar"""
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu("File")
        
        connect_action = QAction("Connect to Server", self)
        connect_action.triggered.connect(self.websocket_client.connect_to_server)
        file_menu.addAction(connect_action)
        
        disconnect_action = QAction("Disconnect", self)
        disconnect_action.triggered.connect(self.websocket_client.disconnect_from_server)
        file_menu.addAction(disconnect_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # View menu
        view_menu = menubar.addMenu("View")
        
        fullscreen_action = QAction("Toggle Fullscreen", self)
        fullscreen_action.setShortcut("F11")
        fullscreen_action.triggered.connect(self.toggle_fullscreen)
        view_menu.addAction(fullscreen_action)
        
        # Help menu
        help_menu = menubar.addMenu("Help")
        
        about_action = QAction("About", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
    
    def setup_connections(self):
        """Setup signal connections"""
        # WebSocket connections
        self.websocket_client.connected.connect(self.on_connected)
        self.websocket_client.disconnected.connect(self.on_disconnected)
        self.websocket_client.message_received.connect(self.on_message_received)
        self.websocket_client.error_occurred.connect(self.on_error)
        self.websocket_client.connection_status_changed.connect(self.update_connection_status)
    
    def setup_system_tray(self):
        """Setup system tray icon"""
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.tray_icon = QSystemTrayIcon(self)
            
            # Set icon (you would use a real icon file)
            icon = self.style().standardIcon(QStyle.SP_ComputerIcon)
            self.tray_icon.setIcon(icon)
            
            # Create tray menu
            tray_menu = self.tray_icon.contextMenu() or self.tray_icon.setContextMenu(self.create_tray_menu())
            
            self.tray_icon.show()
            self.tray_icon.messageClicked.connect(self.show)
    
    def create_tray_menu(self):
        """Create system tray menu"""
        from PySide6.QtWidgets import QMenu
        
        menu = QMenu()
        
        show_action = menu.addAction("Show")
        show_action.triggered.connect(self.show)
        
        hide_action = menu.addAction("Hide")
        hide_action.triggered.connect(self.hide)
        
        menu.addSeparator()
        
        quit_action = menu.addAction("Quit")
        quit_action.triggered.connect(QApplication.quit)
        
        return menu
    
    def on_connected(self):
        """Handle WebSocket connection"""
        self.status_bar.showMessage("Connected to server", 3000)
        logger.info("UI connected to server")
    
    def on_disconnected(self):
        """Handle WebSocket disconnection"""
        self.status_bar.showMessage("Disconnected from server", 3000)
        logger.warning("UI disconnected from server")
    
    def on_message_received(self, message: dict):
        """Handle received WebSocket message"""
        message_type = message.get("type")
        
        if message_type == "response":
            # Add AI response to conversation
            text = message.get("text", "")
            self.conversation_widget.add_message("AI Teddy", text)
        
        elif message_type == "system_status":
            # Update dashboard metrics
            # TODO: Implement dashboard updates
            pass
        
        elif message_type == "error":
            error_msg = message.get("message", "Unknown error")
            self.status_bar.showMessage(f"Error: {error_msg}", 5000)
            logger.error("Server error received", message=error_msg)
    
    def on_error(self, error: str):
        """Handle WebSocket error"""
        self.status_bar.showMessage(f"Connection error: {error}", 5000)
        logger.error("WebSocket error", error=error)
    
    def update_connection_status(self, status: str):
        """Update connection status display"""
        self.connection_status_label.setText(status)
        self.dashboard_widget.update_connection_status(status)
    
    def toggle_fullscreen(self):
        """Toggle fullscreen mode"""
        if self.isFullScreen():
            self.showNormal()
        else:
            self.showFullScreen()
    
    def show_about(self):
        """Show about dialog"""
        QMessageBox.about(
            self,
            "About AI Teddy Bear",
            """
            <h3>AI Teddy Bear Enterprise</h3>
            <p>Version 2.0.0</p>
            <p>Modern, secure AI assistant for children</p>
            <p>Built with PySide6 and FastAPI</p>
            <p>© 2025 AI Teddy Team</p>
            """
        )
    
    def save_settings(self):
        """Save application settings"""
        self.settings.setValue("server_url", self.server_url_input.text())
        self.settings.setValue("api_key", self.api_key_input.text())
        self.settings.setValue("sample_rate", self.sample_rate_combo.currentText())
        self.settings.setValue("channels", self.channels_combo.currentIndex())
        self.settings.setValue("dark_mode", self.dark_mode_checkbox.isChecked())
        self.settings.setValue("auto_connect", self.auto_connect_checkbox.isChecked())
        self.settings.setValue("minimize_to_tray", self.minimize_to_tray_checkbox.isChecked())
        
        self.status_bar.showMessage("Settings saved", 2000)
        logger.info("Application settings saved")
    
    def reset_settings(self):
        """Reset settings to defaults"""
        self.server_url_input.setText("ws://localhost:8000")
        self.api_key_input.clear()
        self.sample_rate_combo.setCurrentText("16000")
        self.channels_combo.setCurrentIndex(0)
        self.dark_mode_checkbox.setChecked(False)
        self.auto_connect_checkbox.setChecked(True)
        self.minimize_to_tray_checkbox.setChecked(True)
        
        self.status_bar.showMessage("Settings reset to defaults", 2000)
    
    def save_window_state(self):
        """Save window state"""
        self.settings.setValue("geometry", self.saveGeometry())
        self.settings.setValue("windowState", self.saveState())
    
    def restore_window_state(self):
        """Restore window state"""
        geometry = self.settings.value("geometry")
        if geometry:
            self.restoreGeometry(geometry)
        
        window_state = self.settings.value("windowState")
        if window_state:
            self.restoreState(window_state)
    
    def closeEvent(self, event):
        """Handle close event"""
        if hasattr(self, 'tray_icon') and self.minimize_to_tray_checkbox.isChecked():
            event.ignore()
            self.hide()
            self.tray_icon.showMessage(
                "AI Teddy Bear",
                "Application was minimized to tray",
                QSystemTrayIcon.Information,
                2000
            )
        else:
            self.save_window_state()
            self.websocket_client.disconnect_from_server()
            event.accept()


class ModernTeddyUI:
    """Main UI application class"""
    
    def __init__(self):
        self.app = None
        self.main_window = None
    
    def run(self):
        """Run the application"""
        # Create QApplication
        self.app = QApplication(sys.argv)
        self.app.setApplicationName("AI Teddy Bear")
        self.app.setApplicationVersion("2.0.0")
        self.app.setOrganizationName("AI Teddy Team")
        
        # Set application icon
        # icon = QIcon("path/to/teddy_icon.png")  # Use actual icon file
        # self.app.setWindowIcon(icon)
        
        # Apply modern styling
        self.apply_modern_theme()
        
        # Create main window
        self.main_window = TeddyMainWindow()
        self.main_window.show()
        
        # Setup exception handling
        sys.excepthook = self.handle_exception
        
        # Run application
        try:
            sys.exit(self.app.exec())
        except SystemExit:
            pass
    
    def apply_modern_theme(self):
        """Apply modern theme to application"""
        style = """
        QApplication {
            font-family: 'Segoe UI', 'Arial', sans-serif;
            font-size: 10pt;
        }
        
        QPushButton {
            background-color: #2196F3;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            font-weight: bold;
        }
        
        QPushButton:hover {
            background-color: #1976D2;
        }
        
        QPushButton:pressed {
            background-color: #0D47A1;
        }
        
        QPushButton:disabled {
            background-color: #BBBBBB;
            color: #666666;
        }
        
        QLineEdit {
            border: 2px solid #E0E0E0;
            border-radius: 4px;
            padding: 8px;
            font-size: 10pt;
        }
        
        QLineEdit:focus {
            border-color: #2196F3;
        }
        
        QComboBox {
            border: 2px solid #E0E0E0;
            border-radius: 4px;
            padding: 8px;
            font-size: 10pt;
        }
        
        QTextEdit {
            border: 2px solid #E0E0E0;
            border-radius: 4px;
            padding: 8px;
            font-size: 10pt;
        }
        """
        
        self.app.setStyleSheet(style)
    
    def handle_exception(self, exc_type, exc_value, exc_traceback):
        """Handle uncaught exceptions"""
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return
        
        logger.error("Uncaught exception", 
                    exc_type=exc_type.__name__,
                    exc_value=str(exc_value),
                    exc_info=(exc_type, exc_value, exc_traceback))
        
        # Show error dialog
        if self.main_window:
            QMessageBox.critical(
                self.main_window,
                "Unexpected Error",
                f"An unexpected error occurred:\n\n{exc_type.__name__}: {exc_value}"
            )


def main():
    """Main entry point"""
    try:
        ui = ModernTeddyUI()
        ui.run()
    except Exception as e:
        logger.error("Failed to start UI application", error=str(e))
        sys.exit(1)


if __name__ == "__main__":
    main() 