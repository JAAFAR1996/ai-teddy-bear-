"""
FastAPI API Module
حزمة API مصممة لـ FastAPI
"""

from fastapi import APIRouter

# إنشاء Main API Router
api_router = APIRouter(prefix="/api/v1", tags=["API"])

# Import available endpoints for FastAPI
try:
    from .endpoints import system, children, conversations, audio
except ImportError:
    pass

# تصدير Router
__all__ = ['api_router']