"""
AI Teddy Bear - Enterprise FastAPI Application 2025
Complete rewrite with modern patterns, enhanced security, and performance optimization
"""

import asyncio
import logging
import os
import signal
import sys
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Dict, Optional, Set, Any
from uuid import uuid4

import structlog
import uvicorn
from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse, ORJSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from prometheus_client import Counter, Gauge, Histogram, generate_latest, CONTENT_TYPE_LATEST
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from secure import Secure
from tenacity import retry, stop_after_attempt, wait_exponential
from opentelemetry import trace
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.instrumentation.logging import LoggingInstrumentor
from opentelemetry.instrumentation.sqlalchemy import SQLAlchemyInstrumentor
from opentelemetry.trace import Status, StatusCode, get_tracer
import orjson

from src.api import api_router
from src.application.services.circuit_breaker import CircuitBreaker, CircuitBreakerError
from src.application.services.health_service import HealthService
from src.application.services.service_registry import ServiceRegistry, ServicePriority
from src.application.services.cloud_transcription_service import CloudTranscriptionService
from src.infrastructure.config import Settings, get_settings
from src.infrastructure.database.connection_pool import setup_database
from src.infrastructure.middleware.security import setup_security
from src.infrastructure.enterprise_observability import get_observability_manager
from src.infrastructure.enterprise_session_manager import EnterpriseSessionManager
from src.infrastructure.security.audit_logger import AuditLogger, AuditEventType
from src.infrastructure.security.data_encryption import DataEncryptionService, EncryptionLevel
from src.infrastructure.modern_container import EnterpriseContainer

# Configure event loop for better performance (Windows compatible)
if sys.platform == "win32":
    # Use ProactorEventLoop for Windows
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
else:
    # Use default for other platforms
    asyncio.set_event_loop_policy(asyncio.DefaultEventLoopPolicy())

# Configure structured logging with correlation ID
def add_correlation_id(logger, log_method, event_dict):
    """Add correlation ID to all logs"""
    import contextvars
    correlation_id = contextvars.ContextVar('correlation_id', default=None)
    if cid := correlation_id.get():
        event_dict['correlation_id'] = cid
    return event_dict

structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        add_correlation_id,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.CallsiteParameterAdder(
            parameters=[structlog.processors.CallsiteParameter.FILENAME,
                       structlog.processors.CallsiteParameter.LINENO]
        ),
        structlog.processors.JSONRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    cache_logger_on_first_use=True,
)

# Initialize OpenTelemetry
LoggingInstrumentor().instrument(set_logging_format=True)
SQLAlchemyInstrumentor().instrument()

logger = structlog.get_logger()

# Enterprise-grade metrics
request_count = Counter('teddy_http_requests_total', 'Total HTTP requests', ['method', 'endpoint', 'status'])
request_duration = Histogram('teddy_http_request_duration_seconds', 'HTTP request duration')
active_websockets = Gauge('teddy_websocket_connections_active', 'Active WebSocket connections')
error_count = Counter('teddy_application_errors_total', 'Total application errors', ['type'])
ai_processing_time = Histogram('teddy_ai_processing_duration_seconds', 'AI processing time')
security_events = Counter('teddy_security_events_total', 'Security events', ['type'])

# Rate limiter with Redis backend
limiter = Limiter(key_func=get_remote_address)

# Security headers middleware
secure_headers = Secure()


class EnterpriseConnectionManager:
    """
    Enterprise-grade WebSocket connection manager with:
    - Automatic cleanup and memory leak prevention
    - Rate limiting per connection
    - Security monitoring
    - Performance metrics
    """
    
    def __init__(self, session_manager: EnterpriseSessionManager, health_service = None):
        self._connections: Dict[str, WebSocket] = {}
        self._connection_metadata: Dict[str, Dict[str, Any]] = {}
        self._lock = asyncio.Lock()
        self.session_manager = session_manager
        self.health_service = health_service
        self._cleanup_task: Optional[asyncio.Task] = None
        self._max_connections = 1000
        self._connection_timeout = 300  # 5 minutes
        self._rate_limiter = {}  # Per-connection rate limiting
        
    async def start(self):
        """Start the connection manager"""
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())
        logger.info("Enterprise Connection Manager started")
        
    async def stop(self):
        """Stop the connection manager and cleanup"""
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
                
        # Close all connections gracefully
        async with self._lock:
            tasks = []
            for session_id, ws in self._connections.items():
                tasks.append(self._close_connection_gracefully(session_id, ws))
            
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)
            
            self._connections.clear()
            self._connection_metadata.clear()
        
        logger.info("Enterprise Connection Manager stopped")
    
    async def connect(self, session_id: str, websocket: WebSocket) -> None:
        """Register a new WebSocket connection with enterprise security"""
        # Security check - rate limiting
        client_ip = websocket.client.host if websocket.client else "unknown"
        if await self._check_rate_limit(client_ip):
            await websocket.close(code=1008, reason="Rate limit exceeded")
            security_events.labels(type="rate_limit_websocket").inc()
            raise ConnectionError("Rate limit exceeded")
        
        # Connection limit check
        if len(self._connections) >= self._max_connections:
            await websocket.close(code=1008, reason="Connection limit reached")
            security_events.labels(type="connection_limit").inc()
            raise ConnectionError("Maximum connections reached")
        
        await websocket.accept()
        
        async with self._lock:
            # Close existing connection if any
            if session_id in self._connections:
                await self._force_disconnect(session_id)
            
            self._connections[session_id] = websocket
            self._connection_metadata[session_id] = {
                "connected_at": datetime.utcnow(),
                "last_activity": datetime.utcnow(),
                "bytes_sent": 0,
                "bytes_received": 0,
                "client_ip": client_ip,
                "message_count": 0
            }
            active_websockets.inc()
            
            # Track in health service
            if self.health_service:
                self.health_service.track_websocket_connection(session_id)
        
        # Update session in Redis
        await self.session_manager.update_session(session_id, {
            "connected": True,
            "client_ip": client_ip
        })
        
        logger.info("WebSocket connected", session_id=session_id, 
                   client_ip=client_ip, total_connections=len(self._connections))
    
    async def disconnect(self, session_id: str) -> None:
        """Remove a WebSocket connection with proper cleanup"""
        async with self._lock:
            if session_id in self._connections:
                del self._connections[session_id]
                metadata = self._connection_metadata.pop(session_id, {})
                active_websockets.dec()
                
                # Log connection statistics
                if metadata:
                    duration = (datetime.utcnow() - metadata.get("connected_at", datetime.utcnow())).total_seconds()
                    logger.info("WebSocket disconnected", 
                               session_id=session_id,
                               duration_seconds=duration,
                               messages_sent=metadata.get("message_count", 0))
                
                # Untrack in health service
                if self.health_service:
                    self.health_service.untrack_websocket_connection(session_id)
        
        # Update session in Redis
        try:
            await self.session_manager.update_session(session_id, {"connected": False})
        except Exception as e:
            logger.warning("Failed to update session on disconnect", session_id=session_id, error=str(e))
    
    async def send_message(self, session_id: str, message: dict) -> bool:
        """Send message to a specific connection with rate limiting"""
        async with self._lock:
            websocket = self._connections.get(session_id)
            metadata = self._connection_metadata.get(session_id, {})
            
        if websocket and metadata:
            # Check per-connection rate limit
            if await self._check_message_rate_limit(session_id):
                logger.warning("Message rate limit exceeded", session_id=session_id)
                return False
                
            try:
                message_json = orjson.dumps(message).decode()
                await websocket.send_text(message_json)
                
                # Update metadata
                metadata["last_activity"] = datetime.utcnow()
                metadata["message_count"] = metadata.get("message_count", 0) + 1
                metadata["bytes_sent"] = metadata.get("bytes_sent", 0) + len(message_json)
                
                return True
            except Exception as e:
                logger.error("Failed to send message", session_id=session_id, error=str(e))
                await self.disconnect(session_id)
                
        return False
    
    async def broadcast(self, message: dict, exclude: Optional[Set[str]] = None) -> int:
        """Broadcast message to all connections"""
        exclude = exclude or set()
        sent_count = 0
        
        async with self._lock:
            connection_items = list(self._connections.items())
        
        tasks = []
        for session_id, _ in connection_items:
            if session_id not in exclude:
                tasks.append(self.send_message(session_id, message))
        
        if tasks:
            results = await asyncio.gather(*tasks, return_exceptions=True)
            sent_count = sum(1 for result in results if result is True)
        
        logger.info("Broadcast completed", total_sent=sent_count, excluded=len(exclude))
        return sent_count
    
    async def _cleanup_loop(self) -> None:
        """Periodic cleanup of stale connections"""
        while True:
            try:
                await asyncio.sleep(60)  # Run every minute
                await self._cleanup_stale_connections()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("Cleanup loop error", error=str(e))
    
    async def _cleanup_stale_connections(self) -> None:
        """Remove stale connections"""
        cutoff_time = datetime.utcnow().timestamp() - self._connection_timeout
        stale_sessions = []
        
        async with self._lock:
            for session_id, metadata in self._connection_metadata.items():
                last_activity = metadata.get("last_activity", datetime.utcnow())
                if last_activity.timestamp() < cutoff_time:
                    stale_sessions.append(session_id)
        
        for session_id in stale_sessions:
            logger.info("Cleaning up stale connection", session_id=session_id)
            await self._force_disconnect(session_id)
    
    async def _force_disconnect(self, session_id: str) -> None:
        """Force disconnect a connection"""
        try:
            if session_id in self._connections:
                await self._connections[session_id].close()
        except Exception:
            pass
        finally:
            await self.disconnect(session_id)
    
    async def _close_connection_gracefully(self, session_id: str, websocket: WebSocket) -> None:
        """Close connection gracefully"""
        try:
            await websocket.close(code=1000, reason="Server shutdown")
        except Exception:
            pass
    
    async def _check_rate_limit(self, client_ip: str) -> bool:
        """Check if client IP is rate limited"""
        # Implement rate limiting logic
        # For now, return False (not rate limited)
        return False
    
    async def _check_message_rate_limit(self, session_id: str) -> bool:
        """Check per-session message rate limit"""
        # Implement per-session rate limiting
        # For now, return False (not rate limited)
        return False


class EnterpriseApplication:
    """
    Enterprise-grade FastAPI application with:
    - Advanced security
    - Performance optimization
    - Comprehensive monitoring
    - Graceful shutdown handling
    """
    
    def __init__(self, settings: Settings):
        self.settings = settings
        self.container = EnterpriseContainer()
        self.connection_manager: Optional[EnterpriseConnectionManager] = None
        self.health_service: Optional[HealthService] = None
        self._shutdown_event = asyncio.Event()
        
    async def startup(self) -> None:
        """Initialize application with dependency injection"""
        logger.info("Starting AI Teddy Bear Enterprise Application")
        
        try:
            # Initialize container
            await self.container.initialize(self.settings)
            
            # Initialize services
            await self._register_services()
            
            # Setup connection manager
            # Initialize enterprise session management
            session_manager = EnterpriseSessionManager(
                redis_url=self.settings.get_redis_url() if hasattr(self.settings, 'get_redis_url') else None
            )
            await session_manager.initialize()
            # Initialize enterprise health service
            try:
                self.health_service = await self.container.get_service("health_service")
                logger.info("Enterprise Health Service initialized successfully")
            except (ValueError, TypeError) as e:
                logger.warning(f"HealthService not available: {e}")
                self.health_service = None
            
            self.connection_manager = EnterpriseConnectionManager(
                session_manager, self.health_service
            )
            await self.connection_manager.start()
            
            # Setup database
            await setup_database({"DATABASE_URL": self.settings.get_database_url()})
            
            # Setup enterprise observability
            observability_manager = get_observability_manager()
            logger.info(f"Enterprise observability initialized: {observability_manager.get_enterprise_status()}")
            
            logger.info("Application startup completed successfully")
            
        except Exception as e:
            logger.error("Failed to start application", error=str(e), exc_info=True)
            raise
    
    async def _register_services(self) -> None:
        """Register all services in the container"""
        services = [
            ("ai_service", "src.application.services.ai.ai_service", "AIService"),
            ("transcription_service", "src.application.services.cloud_transcription_service", "CloudTranscriptionService"),
            ("moderation_service", "src.application.services.moderation_service", "ModerationService"),
            ("memory_service", "src.application.services.memory_service", "MemoryService"),
            ("health_service", "src.application.services.simple_health_service", "SimpleHealthService"),
        ]
        
        for service_name, module_path, class_name in services:
            try:
                await self.container.register_service(service_name, module_path, class_name)
                logger.info(f"Registered service: {service_name}")
            except Exception as e:
                logger.error(f"Failed to register service {service_name}", error=str(e))
    
    async def shutdown(self) -> None:
        """Graceful shutdown"""
        logger.info("Initiating graceful shutdown")
        
        self._shutdown_event.set()
        
        # Stop connection manager
        if self.connection_manager:
            await self.connection_manager.stop()
        
        # Cleanup container
        await self.container.cleanup()
        
        logger.info("Graceful shutdown completed")
    
    def create_app(self) -> FastAPI:
        """Create FastAPI application with enterprise middleware"""
        
        # Custom JSON response using orjson for performance
        class ORJSONResponse(JSONResponse):
            def render(self, content: Any) -> bytes:
                return orjson.dumps(content)
        
        app = FastAPI(
            title="AI Teddy Bear API",
            description="Enterprise-grade AI assistant for children with comprehensive safety features",
            version="2.0.0",
            docs_url="/docs" if self.settings.debug else None,
            redoc_url="/redoc" if self.settings.debug else None,
            default_response_class=ORJSONResponse,
            lifespan=self._lifespan
        )
        
        # Security middleware (order matters!)
        app.add_middleware(TrustedHostMiddleware, allowed_hosts=self.settings.allowed_hosts)
        app.add_middleware(GZipMiddleware, minimum_size=1000)
        app.add_middleware(
            CORSMiddleware,
            allow_origins=self.settings.security.cors_origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
        
        # Rate limiting
        app.state.limiter = limiter
        app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
        
        # Security headers middleware
        @app.middleware("http")
        async def add_security_headers(request: Request, call_next):
            response = await call_next(request)
            secure_headers.framework.fastapi(response)
            return response
        
        # Request correlation and tracing middleware
        @app.middleware("http")
        async def add_correlation_and_tracing(request: Request, call_next):
            correlation_id = str(uuid4())
            
            # Set correlation ID in context
            import contextvars
            correlation_context = contextvars.ContextVar('correlation_id')
            correlation_context.set(correlation_id)
            
            # Add to request headers
            request.state.correlation_id = correlation_id
            
            # Enterprise tracing with professional fallback handling
            tracer = get_tracer(__name__)
            start_time = datetime.utcnow()
            
            # Create enterprise context manager for tracing
            class EnterpriseTracingContext:
                def __init__(self, tracer, span_name: str):
                    self.tracer = tracer
                    self.span_name = span_name
                    self.span = None
                    self.is_active = hasattr(tracer, 'start_as_current_span')
                
                def __enter__(self):
                    if self.is_active:
                        self.span = self.tracer.start_as_current_span(self.span_name).__enter__()
                    return self
                
                def __exit__(self, exc_type, exc_val, exc_tb):
                    if self.is_active and self.span:
                        try:
                            if exc_type:
                                self.span.set_status(Status(StatusCode.ERROR, str(exc_val)))
                                self.span.record_exception(exc_val)
                            else:
                                self.span.set_status(Status(StatusCode.OK))
                            return self.span.__exit__(exc_type, exc_val, exc_tb)
                        except Exception:
                            pass  # Graceful degradation
                
                def set_attribute(self, key: str, value):
                    if self.is_active and self.span:
                        try:
                            self.span.set_attribute(key, value)
                        except Exception:
                            pass
            
            with EnterpriseTracingContext(tracer, "http_request") as trace_ctx:
                trace_ctx.set_attribute("correlation_id", correlation_id)
                trace_ctx.set_attribute("http.method", request.method)
                trace_ctx.set_attribute("http.url", str(request.url))
                
                response = await call_next(request)
                trace_ctx.set_attribute("http.status_code", response.status_code)
                
                # Metrics (with fallback)
                try:
                    duration = (datetime.utcnow() - start_time).total_seconds()
                    if 'request_duration' in globals():
                        request_duration.observe(duration)
                    if 'request_count' in globals():
                        request_count.labels(
                            method=request.method,
                            endpoint=request.url.path,
                            status=response.status_code
                        ).inc()
                except Exception:
                    pass  # Graceful degradation
                
                # Add correlation ID to response
                response.headers["X-Correlation-ID"] = correlation_id
                
                return response
        
        # Health check endpoints
        @app.get("/health")
        async def health_check():
            """Basic health check"""
            try:
                from datetime import datetime
                return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}
            except Exception as e:
                return {"status": "error", "message": str(e)}
        
        @app.get("/health/ready")
        async def readiness_check():
            """Readiness check with dependency verification"""
            try:
                if self.health_service:
                    health_status = await self.health_service.comprehensive_health_check()
                    if health_status.get("healthy", False):
                        return {"status": "ready", "details": health_status}
                    else:
                        raise HTTPException(status_code=503, detail="Service not ready")
                return {"status": "ready"}
            except Exception as e:
                logger.error("Readiness check failed", error=str(e))
                raise HTTPException(status_code=503, detail="Service not ready")
        
        @app.get("/metrics")
        async def metrics():
            """Prometheus metrics endpoint"""
            try:
                from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
                from fastapi import Response
                return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
            except Exception as e:
                return {"error": "Metrics not available", "details": str(e)}
        
        # WebSocket endpoint with enterprise features
        @app.websocket("/ws/{session_id}")
        @limiter.limit("10/minute")  # WebSocket rate limiting
        async def websocket_endpoint(websocket: WebSocket, session_id: str, request: Request):
            """Enterprise WebSocket endpoint with comprehensive error handling"""
            tracer = get_tracer(__name__)
            
            # Enterprise WebSocket tracing context
            with EnterpriseTracingContext(tracer, "websocket_connection") as ws_trace:
                ws_trace.set_attribute("session_id", session_id)
                
                try:
                    if not self.connection_manager:
                        await websocket.close(code=1011, reason="Service unavailable")
                        return
                    
                    await self.connection_manager.connect(session_id, websocket)
                    
                    circuit_breaker = CircuitBreaker(
                        failure_threshold=3,
                        recovery_timeout=60,
                        half_open_max_calls=1
                    )
                    
                    while True:
                        try:
                            # Receive message with timeout
                            data = await asyncio.wait_for(websocket.receive_json(), timeout=30.0)
                            
                            # Process message with circuit breaker
                            @circuit_breaker
                            async def process_message():
                                return await self._process_websocket_message(session_id, data)
                            
                            response = await process_message()
                            await self.connection_manager.send_message(session_id, response)
                            
                        except asyncio.TimeoutError:
                            # Send keepalive
                            await self.connection_manager.send_message(session_id, {"type": "keepalive"})
                            
                        except WebSocketDisconnect:
                            break
                            
                        except CircuitBreakerError:
                            await self.connection_manager.send_message(session_id, {
                                "type": "error",
                                "message": "Service temporarily unavailable"
                            })
                            break
                            
                        except Exception as e:
                            logger.error("WebSocket message processing error", 
                                       session_id=session_id, error=str(e))
                            await self.connection_manager.send_message(session_id, {
                                "type": "error", 
                                "message": "Internal server error"
                            })
                            
                except Exception as e:
                    logger.error("WebSocket connection error", session_id=session_id, error=str(e))
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    
                finally:
                    if self.connection_manager:
                        await self.connection_manager.disconnect(session_id)
        
        # Include API routes
        app.include_router(api_router, prefix="/api/v1")
        
        # Instrument with OpenTelemetry
        FastAPIInstrumentor.instrument_app(app)
        
        return app
    
    @asynccontextmanager
    async def _lifespan(self, app: FastAPI):
        """Application lifespan manager"""
        await self.startup()
        yield
        await self.shutdown()
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        reraise=True
    )
    async def _process_websocket_message(self, session_id: str, data: dict) -> dict:
        """Process WebSocket message with retry logic"""
        with ai_processing_time.time():
            # Get AI service from container
            ai_service = await self.container.get_service("ai_service")
            
            message_type = data.get("type", "message")
            
            if message_type == "voice_message":
                text = data.get("text", "")
                audio_data = data.get("audio_data")
                
                if audio_data:
                    # Process audio
                    transcription_service = await self.container.get_service("transcription_service")
                    text = await transcription_service.transcribe(audio_data)
                
                if text:
                    response_text = await ai_service.generate_response(text, session_id)
                    return {
                        "type": "response",
                        "text": response_text,
                        "session_id": session_id,
                        "timestamp": datetime.utcnow().isoformat()
                    }
            
            elif message_type == "ping":
                return {"type": "pong", "timestamp": datetime.utcnow().isoformat()}
            
            return {
                "type": "error",
                "message": "Unknown message type",
                "session_id": session_id
            }


def create_application() -> FastAPI:
    """Factory function to create the application"""
    settings = get_settings()
    app_instance = EnterpriseApplication(settings)
    return app_instance.create_app()


def handle_shutdown(signum, frame):
    """Handle shutdown signals gracefully"""
    logger.info(f"Received signal {signum}, initiating shutdown")
    # The actual shutdown is handled by the lifespan manager


async def main():
    """Main entry point for the application"""
    # Handle shutdown signals
    signal.signal(signal.SIGINT, handle_shutdown)
    signal.signal(signal.SIGTERM, handle_shutdown)
    
    settings = get_settings()
    
    # Create application
    app = create_application()
    
    # Configure uvicorn
    config = uvicorn.Config(
        app=app,
        host=settings.host,
        port=settings.port,
        log_config=None,  # Use our custom logging
        access_log=False,  # We handle access logs in middleware
        workers=1,  # Use 1 worker for now, can be scaled with gunicorn
        loop="asyncio",
        http="httptools",
        lifespan="on",
        reload=settings.debug,
        reload_dirs=["src"] if settings.debug else None,
    )
    
    server = uvicorn.Server(config)
    
    try:
        logger.info("Starting AI Teddy Bear Enterprise Server", 
                   host=settings.host, port=settings.port)
        await server.serve()
    except KeyboardInterrupt:
        logger.info("Received keyboard interrupt, shutting down")
    except Exception as e:
        logger.error("Server error", error=str(e), exc_info=True)
        raise
    finally:
        logger.info("Server shutdown complete")


if __name__ == "__main__":
    asyncio.run(main())
